--==============================================================================
--File:     LuaQuest_Gameplay
--Author:   Myque Ouellette
--Date:     December 11, 2006
--Descript: Gameplay-specific functions such as shop and combat
--==============================================================================


--defines a global shop list until enter a new shop
gShopList = {}

--=======================================
-- function:  ShopItemList
-- author:    Eric Bakutis
-- created:   July 17, 2007
-- returns:   n/a
-- descript:  Generates a list from a shop when given a player
--=======================================
function ShopItemList()

    --create local integers for the table elements and define them based on
    --player attributes

    --Create a table element for training based on values in gPlayer
    local iTraining = gPlayer.level * 50
    --Create a string to describe the Training item
    local sTrainingName = "Train to the next level (" .. gPlayer.level + 1 .. ")"

    --Create a table element for healing based on values in gPlayer
    local iHealing = gPlayer.hitPoints - gPlayer.maxHP
    --Create a string to describe the Healing item
    local sHealingName = "Heal " .. -iHealing .. " HP"

    --create new table entries based on the data in Player
    local tTraining = {
        type = sTrainingName,
        name = "Training",
        cost = iTraining,
        --table = {5, 5, gActorTable[8]}  debugging, testing table in table
    }
    local tHealing = {
        type = sHealingName,
        name = "Healing",
        cost = -iHealing
    }

    --create local tables for the table elements that we'll define below
    local tWeapon1
    local tWeapon2
    local tArmor1
    local tArmor2
    
    --create local tables for weapons and armor available to the player--these
    --need to be different from those tables used by the game because the game
    --tables may include monster only items the player shouldn't buy.
    local tWeaponTable = {}
    local tArmorTable = {}

    --get the number of indexes in the weapon table
    --we do this to allow this function to work should coders expand the
    --weapons table beyond the 8 included now.
    local iWeaponTableLength = table.getn(gWeaponTable)

    --get the number of indexes in the armor table
    --we do this to allow this function to work should coders expand the
    --armor table beyond the 8 included now.
    local iArmorTableLength = table.getn(gArmorTable)

    --sort through gWeaponTable and remove any weapons with cost 'na'... these
    --are monster weapons we don't want the player to be able to buy.
    for i = 1,iWeaponTableLength do
        if (gWeaponTable[i].cost ~= "na") then
            table.insert(tWeaponTable, gWeaponTable[i])
        end
    end
    
    --now update iWeaponTableLength to the revised length without monster weps
    iWeaponTableLength = table.getn(tWeaponTable)

    --sort through gArmorTable and remove any armor with cost 'na'... these
    --are monster armor we don't want the player to be able to buy.
    for j = 1,iArmorTableLength do
        if (gArmorTable[j].cost ~= "na") then
            table.insert(tArmorTable, gArmorTable[j])
        end
    end
    
    --now update iArmorTableLength to the revised length without monster armor
    iArmorTableLength = table.getn(tArmorTable)

    --let's start by getting our random weapons
    --get the first random weapon from the weapon table
    --get a random number between 1 and the length of the table
    local iFirstWep = math.random(1,iWeaponTableLength)

    --get the second random weapon from the weapon table
    --get a random number between 1 and the length of the table
    local iSecondWep = math.random(1,iWeaponTableLength)

    --error checking... avoid picking the same weapon twice
    --set bSameWeapon to true by default
    local bSameWeapon = true

    --repeat the random function as long as bSameWeapon is true
    while bSameWeapon do
        --if first wep index does not equal second wep index, set bSameWeapon
        --to false in order to exit the loop--we know we have two separate
        --weapons
        if(iFirstWep ~= iSecondWep) then
            bSameWeapon = false
        --otherwise, we know we got the same number twice--so, keep bSameWeapon
        --true...
        else
            --...and get a new random weapon, then compare again
            iSecondWep = math.random(1,iWeaponTableLength)
        end
    end

    --now that we have good and different random numbers, get random weps
    --and assign them to our previously created tables.
    tWeapon1 = tWeaponTable[iFirstWep]
    tWeapon2 = tWeaponTable[iSecondWep]

    --now let's get our random armor
    --get the first random armo from the armor table
    --get a random number between 1 and the length of the table
    local iFirstArmor = math.random(1,iArmorTableLength-1)

    --get the second random armor from the armor table
    --get a random number between 1 and the length of the table
    local iSecondArmor = math.random(1,iArmorTableLength-1)

    --error checking... avoid picking the same armor twice
    --set bSameArmor to true by default
    local bSameArmor = true

    --repeat the random function while bSameArmor is true
    while bSameArmor do
        --if first armor index does not equal second armor index, set
        --bSameArmor to false in order to exit the loop--we know we have
        --two separate sets of armor
        if(iFirstArmor ~= iSecondArmor) then
            bSameArmor = false
        --otherwise, we know we got the same number twice--so, keep bSameArmor
        --true...
        else
            --...and get a new random armor, then compare again
            iSecondArmor = math.random(1,iArmorTableLength-1)
        end
    end

    --now that we have good and different random numbers, get random armor
    --and assign them to our previously created tables.
    tArmor1 = tArmorTable[iFirstArmor]
    tArmor2 = tArmorTable[iSecondArmor]

    --now that we have our training cost, health cost, and random items,
    --let's go ahead and make our shop table
    local tShopTable = {
        tTraining,
        tHealing,
        tWeapon1,
        tWeapon2,
        tArmor1,
        tArmor2,
    }

    --As a final step, we'll print our final random shop list for the user
    --print("The following items are available at this shop:\n")
    --PrintTable(tShopTable)
    return tShopTable

end


-- ==============================================================================
-- Function: ShopItemDisplay(tbl)
-- Author:   Myque Ouellette
-- Date:     May 24, 2006
-- Returns:  nothing
-- Descript: Takes and equipment list and prints it on screen
-- ==============================================================================
function ShopItemDisplay(tbl)

        -- ID, string, xpos, ypos, time to display (0-inf ms), font(1-2)
        TempMsg(61, "Your home base has the following items:", 300,200, "inf", 1)
        TempMsg(62, "Fuel - 1 Resource Point per Fuel Point.", 300, 220, "inf", 1)
        TempMsg(64, "Bullets - 1 Resource Point per Bullet.", 300, 240, "inf", 1)
        TempMsg(66, "Bombs - 5 Resource Points per Bomb", 300, 260, "inf", 1)
        TempMsg(68, "Armor - 1 Resource Point per Armor Point.", 300, 280, "inf", 1)
        TempMsg(70, "You currently have " .. gPlayer.gold .. " Resource Points.", 300, 320, "inf", 1)
        TempMsg(72, "Type 'exit' to exit the shop", 300, 340, "inf", 1)


-- original shop text from LUAQuest
--         TempMsg(62, tbl[1].name .. " - " .. tbl[1].type .. " - " .. tbl[1].cost .. " gold.", 400, 220, "inf", 1)
--         TempMsg(64, tbl[2].name .. " - " .. tbl[2].type .. " - " .. tbl[2].cost .. " gold.", 400, 240, "inf", 1)
--         TempMsg(66, tbl[3].name .. " - " .. tbl[3].type .. " - " .. tbl[3].cost .. " gold.", 400, 260, "inf", 1)
--         TempMsg(68, tbl[4].name .. " - " .. tbl[4].type .. " - " .. tbl[4].cost .. " gold.", 400, 280, "inf", 1)
--         TempMsg(70, tbl[5].name .. " - " .. tbl[5].type .. " - " .. tbl[5].cost .. " gold.", 400, 300, "inf", 1)
--         TempMsg(72, tbl[6].name .. " - " .. tbl[6].type .. " - " .. tbl[6].cost .. " gold.", 400, 320, "inf", 1)
--         TempMsg(74, "You currently have " .. gPlayer.gold .. " gold.", 400, 360, "inf", 1)
--         TempMsg(76, "Type 'exit' to exit the shop", 400, 380, "inf", 1)

end


--=======================================
-- function:  Combat
-- author:    Eric Bakutis
-- created:   July 17, 2007
-- returns:   n/a
-- descript:  Handles a combat round between an attacker and defender
--=======================================
function Combat(Attacker,Defender)

    --errorcheck... if a combat round is in progress, return, we don't want
    --to do more than one combat round every two seconds to avoid overlapping
    --text messages. If a combat round is not in progress, we start one.
    if (gCombatState == true) then
        return
    else
        gCombatState = true
    end

    --create local variables for attack and defense
    local Attack
    local WeaponRating
    local WeaponDamage
    local Defense
    local ArmorRating

    --error checking begins here

    --error check--make sure defender is alive--otherwise, abort attack
    --if the defender is already dead (active = false)...
    if Defender.active == false then
        --tell attacker they are hitting a corpse...
        TempMsg("Can't attack that... it's already dead!")
        --and abort the function
        return
    end

    --errorcheck--the chopper should never initiate combat w/ physical contact
    --so you can't land on zombies--I changed this because occasionally it 
    --would cause the game to crash. The zombies can attack a landed chopper,
    --but attempting to land on zombies operates just like trying to land on
    --a human or terrain... you can't do it.
    if (Attacker.type == "player") then
        --the chopper can't initiate combat, only be attacked, so return
        return
    end

    --start by setting attack equal to the Attacker's str + dex
    Attack = Attacker["strength"] + Attacker["dexterity"]

    --find the weapon Attacker has and get the damage of that weapon
    --find out how long the weapon table is
    local iWeaponTableLength = table.getn(gWeaponTable)

    --cycle through table to match weapon in table to weapon held by Attacker
    for index = 1, iWeaponTableLength do
        --if the name of the weapon in the index being examined matches the
        --name of the Attacker's, record that weapon's damage in WeaponRating
        if gWeaponTable[index].name == Attacker.weapon then
            WeaponRating = gWeaponTable[index].damage
        end
    end

    --Now that we have the damage rating of the weapon, base a random on that
    --The damage by the weapon is 1 to it's max damage, set by WeaponRating
    WeaponDamage = math.random(1,WeaponRating)

    --Now finalize attack by adding the original var (str+dex) to WeaponDamage
    Attack = Attack + WeaponDamage

    --the next step is to get the defense of the creature being attacked
    --start by setting defense equal to the Defender's toughness + dex
    Defense = Defender.toughness + Defender.dexterity

    --find the armor of the Defender and get the armor value
    --find out how long the armor table is
    local iArmorTableLength = table.getn(gArmorTable)

    --cycle through table to match armor in it to armor worn by Defender
    for index = 1, iArmorTableLength do
        --if the name of the armor in the index being examined matches the
        --name of the Defender's, record that armor's defense in ArmorRating
        if gArmorTable[index].name == Defender.armor then
            ArmorRating = gArmorTable[index].defense
        end
    end

    --Now finalize defense by adding the original var (dex+tough) to ArmorRating
    Defense = Defense + ArmorRating

    --Now that we have final attack and defense values, do a combat round
    --if the Defender's defense is less than the Attacker's attack...
    if Defense < Attack then
        --deal damage to the Defender based on how much Attack exceed Defense
            local DamageDone = Attack - Defense
            Defender.hitPoints = Defender.hitPoints - DamageDone
            --      ID,    string ,        xpos,ypos, time (0-inf ms),  font(1-2)
            if (Attacker.name == "Player") then
                    TempMsg(50, Attacker.name .. " hits " .. Defender.name .. " for " .. DamageDone .. " damage!", 200, 200, 2000, 1)
            else
                    TempMsg(50, Attacker.name .. " hits " .. Defender.name .. " for " .. DamageDone .. " damage!", 200, 220, 2000, 1)
            end
        --otherwise (attack did not exceed defense) tell the Attacker they missed
    else
        if (Attacker.name == "Player") then
                TempMsg(50, Attacker.name .. " swings wildly at " .. Defender.name .. ", but misses!\n", 200, 200, 2000, 1)
        else
                TempMsg(50, Attacker.name .. " swings wildly at " .. Defender.name .. ", but misses!\n", 200, 220, 2000, 1)
        end
    end

    --Expose the Attack and Defense values
    --TempMsg(Attacker.name .. "'s Attack was: " .. Attack)
    --TempMsg(Defender.name .. "'s Defense was: " .. Defense)
    --TempMsg("")

    --Report remaining HP of both combatants.

    TempMsg(52, Attacker.name .. " has " .. Attacker.hitPoints .. " hitpoints remaining.", 200, 240, 2000, 1)
    TempMsg(54, Defender.name .. " has " .. Defender.hitPoints .. " hitpoints remaining.", 200, 260, 2000, 1)

    --TempMsg("")

    --now check to see if the Defender died... if so, remove them from the game
    if Defender.hitPoints <= 0 then

        TempMsg(60, Defender.name .. " has died.", 200, 280, 2000, 1)

        Defender.active = false

    end

end


--==============================================================================
--Function: Shop(tbl, input)
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  nothing
--Descript: Takes table of equipment and user input and sells item to player
--==============================================================================
function Shop(tbl, input)

    --functions used to work on the input string
    local iStringLength
    local iStringFirst
    local iStringRest
    local sStringFirst
    local sStringFirstFixed
    local sStringRest

    --functions used when working with player properties
    local iPlayerGold
    local iPlayerLevel

    --**************************************************************************
    --placeholder code (to be replaced)
    --TempMsg(1, "Shop Code Not Implemented.  Press ESC to exit.", 100, 200, "inf", 1)
    --end placeholder code
    --**************************************************************************

    --if user said exit, get out of the shop
    if (input == "exit") then

      TempMsg(84, "Get out there and save those people!", 300, 440, 2000, 1)

      --unpause game so monsters move again
      gPlayer.paused = false

      if gTextState == 1 then
         gTextState = 0
         --break out of input loop and clear text
         gInputLoop = false
            for i = 1, 12 do
               TempMsg(i)
            end
      end

      --on exit, clear the shop
      -- ID, string, xpos, ypos, time to display (0-inf ms), font(1-2)
      TempMsg(61, "", 400,200, 1, 1)
      TempMsg(62, "", 400,200, 1, 1)
      TempMsg(64, "", 400,200, 1, 1)
      TempMsg(66, "", 400,200, 1, 1)
      TempMsg(68, "", 400,200, 1, 1)
      TempMsg(70, "", 400,200, 1, 1)
      TempMsg(72, "", 400,200, 1, 1)
      TempMsg(74, "", 400,200, 1, 1)
      TempMsg(76, "", 400,200, 1, 1)
      TempMsg(80, "", 400,200, 1, 1)
      TempMsg(82, "", 400,200, 1, 1)

      return

    else

        --do shop stuff
        --convert input too lowercase
        input = string.lower(input)

        --handle refueling
        if (input == "fuel") then

            --first figure out how much it costs to refuel
            local iFuelCost = gPlayer.maxFuelPoints - gPlayer.fuelPoints

            --check to see if the player is already refueled, in which case
            --the fuelcost is 0.
            if (iFuelCost == 0) then
                TempMsg(84, "You've already loaded as much fuel as you can!", 300, 440, 2000, 1)
                --since we're full on fuel, no need to do anything else

            --else, check to see if the player has the RP to refuel
            elseif (iFuelCost <= gPlayer.gold) then
                --if so, refuel player
                --tell player what happened
                TempMsg(84, "You refueled " .. iFuelCost .. " fuel.", 300, 440, 2000, 1)
                --add fuel to chopper
                gPlayer.fuelPoints = gPlayer.fuelPoints + iFuelCost
                --decrement Resource Points
                gPlayer.gold = gPlayer.gold - iFuelCost

                  --now display shop again
                  ShopItemDisplay(gShopList)
                  gUserInput = ""

            --if the player can't refuel totally, let them fuel up to their RP
            elseif ((iFuelCost > gPlayer.gold) and (gPlayer.gold ~= 0)) then

                --see how much fuel the player can afford
                iFuelCost = gPlayer.gold

                --now refuel player
                --tell player what happened
                TempMsg(84, "You couldn't refuel to full, however, you purchased " .. iFuelCost .. " fuel.", 300, 440, 2000, 1)
                --add fuel to chopper
                gPlayer.fuelPoints = gPlayer.fuelPoints + iFuelCost
                --decrement Resource Points
                gPlayer.gold = gPlayer.gold - iFuelCost

                  --now display shop again
                  ShopItemDisplay(gShopList)
                  gUserInput = ""

            else
                TempMsg(84, "I'm sorry, you don't have enough Resource Points for that.", 300, 440, 2000, 1)

                  --now display shop again
                  ShopItemDisplay(gShopList)
                  gUserInput = ""

            end

        --handle reloading bullets
        elseif (input == "bullets") then

            --first figure out how much it costs to reload
            local iBulletCost = gPlayer.maxBullets - gPlayer.bullets

            --check to see if the player is already reloaded, in which case
            --the reload cost is 0.
            if (iBulletCost == 0) then
                TempMsg(84, "You've already reloaded all the bullets you can!", 300, 440, 2000, 1)
                --since we're full on bullets, no need to do anything else

            --else check to see if the player has the RP to reload
            elseif (iBulletCost <= gPlayer.gold) then
                --if so, reload player's bullets
                --tell player what happened
                TempMsg(84, "You reloaded " .. iBulletCost .. " bullets.", 300, 440, 2000, 1)
                --add bullets to chopper
                gPlayer.bullets = gPlayer.bullets + iBulletCost
                --decrement Rescource Points
                gPlayer.gold = gPlayer.gold - iBulletCost
                
                --now display shop again
                ShopItemDisplay(gShopList)
                gUserInput = ""
                
            --if the player can't reload totally, reload them up to their RP
            elseif ((iBulletCost > gPlayer.gold) and (gPlayer.gold ~= 0)) then

                --see how many bullets the player can afford
                iBulletCost = gPlayer.gold

                --now reload player's bullets
                --tell player what happened
                TempMsg(84, "You couldn't reload to full, however, you purchased " .. iBulletCost .. " bullets.", 300, 440, 2000, 1)
                --add bullets to chopper
                gPlayer.bullets = gPlayer.bullets + iBulletCost
                --decrement Resource Points
                gPlayer.gold = gPlayer.gold - iBulletCost

                  --now display shop again
                  ShopItemDisplay(gShopList)
                  gUserInput = ""

            else
                TempMsg(84, "I'm sorry, you don't have enough Resource Points for that.", 300, 440, 2000, 1)

                  --now display shop again
                  ShopItemDisplay(gShopList)
                  gUserInput = ""

            end

        --handle reloading bombs
        elseif (input == "bombs") then

            --figure out how much it costs to reload
            --bombs cost 5 RPs to reload
            local iBombCost = (gPlayer.maxBombs - gPlayer.bombs) * 5

            --check to see if the player is already reloaded, in which case
            --the reload cost is 0.
            if (iBombCost == 0) then
                TempMsg(84, "You've already reloaded all the bombs you can!", 300, 440, 2000, 1)
                --since we're full on bombs, no need to do anything else

            --else, check to see if the player can reload
            elseif (iBombCost <= gPlayer.gold) then
                --if so, reload player's bombs
                --tell player what happened
                TempMsg(84, "You reloaded " .. (iBombCost/5) .. " bombs.", 300, 440, 2000, 1)
                --add bombs to chopper
                --remember bombs cost 5 apiece, so divide the cost by 5 to
                --load right amount
                gPlayer.bombs = gPlayer.bombs + (iBombCost/5)
                --decrement Resource Points
                gPlayer.gold = gPlayer.gold - iBombCost

                --now display shop again
                ShopItemDisplay(gShopList)
                gUserInput = ""

            --if the player can't reload totally, reload them up to their RP
            elseif ((iBombCost > gPlayer.gold) and (gPlayer.gold ~= 0)) then

                --see how much Resource Points the player has
                iBombCost = gPlayer.gold

                --now see how many times we can pull 5 out of this amount
                --bombs cost 5 RPs per bomb
                local iBombNum = math.floor(iBombCost/5)

                --now update iBombCost to reflect how many bombs we can buy
                iBombCost = iBombNum * 5

                --now reload player's bombs
                --tell player what happened
                TempMsg(84, "You couldn't reload to full, however, you purchased " .. (iBombCost/5) .. " bombs.", 300, 440, 2000, 1)
                --add bullets to chopper
                gPlayer.bombs = gPlayer.bombs + (iBombCost/5)
                --decrement Resource Points
                gPlayer.gold = gPlayer.gold - iBombCost

                  --now display shop again
                  ShopItemDisplay(gShopList)
                  gUserInput = ""

            else
                TempMsg(84, "I'm sorry, you don't have enough Resource Points for that.", 300, 440, 2000, 1)

                  --now display shop again
                  ShopItemDisplay(gShopList)
                  gUserInput = ""

            end

        elseif (input == "armor") then
        
            --first figure out how much it costs to rearmor
            local iArmorCost = gPlayer.maxHP - gPlayer.hitPoints

            --check to see if the player is already rearmored, in which case
            --the reload cost is 0.
            if (iArmorCost == 0) then
                TempMsg(84, "You've already repaired as much armor as you can!", 300, 440, 2000, 1)
                --since we're full on armor, no need to do anything else

            --else check to see if the player has the RP to rearmor
            elseif (iArmorCost <= gPlayer.gold) then
                --if so, repair armor
                --tell player what happened
                TempMsg(84, "You repaired " .. iArmorCost .. " armor points.", 300, 440, 2000, 1)
                --add armor to chopper
                gPlayer.hitPoints = gPlayer.hitPoints + iArmorCost
                --decrement Rescource Points
                gPlayer.gold = gPlayer.gold - iArmorCost

                --now display shop again
                ShopItemDisplay(gShopList)
                gUserInput = ""

            --if the player can't repair totally, repair them up to their RP
            elseif ((iArmorCost > gPlayer.gold) and (gPlayer.gold ~= 0)) then

                --see how much armor the player can afford
                iArmorCost = gPlayer.gold

                --now repair player's armor
                --tell player what happened
                TempMsg(84, "You couldn't repair to full, however, you repaired " .. iArmorCost .. " armor points.", 300, 440, 2000, 1)
                --add armor to chopper
                gPlayer.hitPoints = gPlayer.hitPoints + iArmorCost
                --decrement Resource Points
                gPlayer.gold = gPlayer.gold - iArmorCost

                  --now display shop again
                  ShopItemDisplay(gShopList)
                  gUserInput = ""

            else
                TempMsg(84, "I'm sorry, you don't have enough Resource Points for that.", 300, 440, 2000, 1)

                  --now display shop again
                  ShopItemDisplay(gShopList)
                  gUserInput = ""

            end


        else
            TempMsg(84, "I'm sorry, we don't have that in stock. Anything else?", 300, 440, 2000, 1)

            --now display shop again
            ShopItemDisplay(gShopList)
            gUserInput = ""

        end

        gUserInput = ""

    end

end

--=======================================
-- function:  ParseTextShop
-- author:    Eric Bakutis
-- created:   August 7, 2007
-- returns:   The table associated with a named character from the user
-- descript:  This function searches a table for a named item entered by the
--            user and allows the user to purchase that item or exit the
--            shop, as necessary. If the user enters invalid input, it keeps
--            prompting until they do it right.
--=======================================
function ParseTextShop(tMergedTable, input)

    --make sure the user sent in a table, cancel function if they didn't.
    if type(tMergedTable) ~= "table" then
        --tell the user why the function didn't run
        print("Please enter the name of a valid table.")
        return
    end

    newinput = string.lower(input)

    --get the length of the table given as input
    local iMergedTableLen = table.getn(tMergedTable)

    --hold the index that we found matching the user input
    local iFoundIndex

    --handles getting input from the user
    --input = io.input(io.stdin)

    --set a boolean to determine if we found something or not
    local bFoundUserInput = false

    --let's search each index of the table up to the last index for the name
    --the user entered, with the number of loops sets by iMergedTableLen
    for index = 1,iMergedTableLen do
        for key,value in tMergedTable[index] do
            --if the "name" value in table matches the user input, found it!

            --first need to make value all lower case for comparison
            value = string.lower(value)

            if key == "name" and value == newinput then
                --tell the user we found it, set boolean to true to exit the
                --loop, and then save the table index where we found the name
                --print("Found the name " .. sUserInput .. " in index " .. index .. ".")
                bFoundUserInput = true
                iFoundIndex = index
            end
        end
    end

    --If we didn't find the name AT ALL, return nil
    if bFoundUserInput == false then
        --removing feedback line so it won't double with SelectCombatants
        --print("Could not find the value.")
        --print(iFoundIndex)
        return nil
    --else if we DID find the name, return the table that matches that name
    else
        --removing feedback line so it won't double with SelectCombatants
        return iFoundIndex
        --return tMergedTable[iFoundIndex]
    end

end

