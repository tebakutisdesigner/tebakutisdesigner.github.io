--**************************************
--Weapon Table
--**************************************
gWeaponTable = {}
gWeaponTable[1] = {
    name = "Short Sword",
    type = "weapon",
    damage = 5,
    cost = 5
}
gWeaponTable[2] = {
    name = "Club",
    type = "weapon",
    damage = 7,
    cost = 10
}
gWeaponTable[3] = {
    name = "Long Sword",
    type = "weapon",
    damage = 8,
    cost = 15
}
gWeaponTable[4] = {
    name = "Axe",
    type = "weapon",
    damage = 10,
    cost = 18
}
gWeaponTable[5] = {
    name = "Spear",
    type = "weapon",
    damage = 13,
    cost = 20
}
gWeaponTable[6] = {
    name = "Bastard Sword",
    type = "weapon",
    damage = 15,
    cost = 22
}
gWeaponTable[7] = {
    name = "Massive Club",
    type = "weapon",
    damage = 20,
    cost = "na"
}
gWeaponTable[8] = {
    name = "Claws",
    type = "weapon",
    damage = 15,
    cost = "na"
}
--overpowered, much?
gWeaponTable[9] = {
    name = "Excalibur",
    type = "weapon",
    damage = 60,
    cost = 1
}


--**************************************
--Armor Table
--**************************************
gArmorTable = {}
gArmorTable[1] = {
    name = "Leather",
    type = "armor",
    defense = 5,
    cost = 10
}
gArmorTable[2] = {
    name = "Chain",
    type = "armor",
    defense = 10,
    cost = 20
}
gArmorTable[3] = {
    name = "Scale",
    type = "armor",
    defense = 15,
    cost = 35
}
gArmorTable[4] = {
    name = "Plate",
    type = "armor",
    defense = 20,
    cost = 50
}
gArmorTable[5] = {
    name = "None",
    type = "armor",
    defense = 0,
    cost = "na"
}

--**************************************
--Enemy Table
--**************************************
gEnemyTable = {}
gEnemyTable[1] = {
    type = "monster",
    name = "Goblin",
    hitPoints = 5,
    strength = 5,
    dexterity = 15,
    toughness = 5,
    weapon = "Short Sword",
    armor = "Leather",
    gold = 10,
    bitmap = "goblin"
}
gEnemyTable[2] = {
    type = "monster",
    name = "Orc",
    hitPoints = 10,
    strength = 10,
    dexterity = 10,
    toughness = 10,
    weapon = "Club",
    armor = "Chain",
    gold = 20,
    bitmap = "orc"
}
gEnemyTable[3] = {
    type = "monster",
    name = "Warg",
    hitPoints = 15,
    strength = 15,
    dexterity = 20,
    toughness = 20,
    weapon = "Claws",
    armor = "None",
    gold = 30,
    bitmap = "warg"
}
gEnemyTable[4] = {
    type = "monster",
    name = "Uruk",
    hitPoints = 15,
    strength = 15,
    dexterity = 15,
    toughness = 15,
    weapon = "Bastard Sword",
    armor = "Scale",
    gold = 40,
    bitmap = "uruk"
}
gEnemyTable[5] = {
    type = "monster",
    name = "Troll",
    hitPoints = 20,
    strength = 20,
    dexterity = 5,
    toughness = 25,
    weapon = "Massive Club",
    armor = "None",
    gold = 50,
    bitmap = "troll"
}

