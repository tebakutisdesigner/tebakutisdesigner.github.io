--==============================================================================
--File:     LuaQuest_Init
--Author:   Myque Ouellette
--Date:     December 11, 2006
--Descript: Initial game setup
--Note:     Modified and expanded from meteor_shower.lua
--          by Thatcher Ulrich (November 2001)
--Params:   [-width N] [-height N] [-fullscreen]
--==============================================================================


--define global player variables
gPlayer = {}
gPlayerMove = nil

--we're going to use gPlayerMoveX and Y instead... but I left gPlayerMove in
--to prevent anything from breaking while I track it down
gPlayerMoveX = nil
gPlayerMoveY = nil

gPlayerMaxVelocity = 2; --max velocity the chopper can go

--use this to determine how often we update movement (not every tick)
gPlayerUpdateMovement = 0;
--how often to update movement
gPlayerUpdateMovementFreq = 3;

--define the player's home base
gHomeBase = {}

--define if we've loaded a game, true by default
gGameLoaded = true

--player starts in his home base, so start with gInTown true
--gInTown = true

--define global terrain sprites
gTownSprite = "base"
gTerrainSprite = {
    "terrain1",
    "terrain2",
    "terrain3"
}

--Added by TEB for sorting order
--define global sort order
--*****************************************
--Create tSortOrder table
--created by Eric Bakutis
--this is used in the Gamestate Sort function
--*****************************************
gSortOrder = {}

gSortOrder[1] = "background"
gSortOrder[2] = "terrain"
gSortOrder[3] = "town"
gSortOrder[4] = "actor"
gSortOrder[5] = "monster"
gSortOrder[6] = "bomb" --new for Choplifter
gSortOrder[7] = "player"
gSortOrder[8] = "bullet" --new for Choplifter
gSortOrder[9] = "menuButton"
gSortOrder[10] = "cursor"
gSortOrder[11] = "MonsterGenerator"
gSortOrder[12] = "Player Manager"
gSortOrder[13] = "font"
gSortOrder[14] = "message"


--==============================================================================
-- function:  InitGame
-- author:    Myque Ouellette
-- created:   May 22, 2006
-- returns:   <nil>
-- descript:  Calls elements and functions to set up the game
--==============================================================================
function InitGame()

    RandomSeedGen()

    --**************************************************************************
    --this loads in .csv files using LoadChar in LQ_UserFunctions

    --load in enemy templates
    gEnemyTable=LoadChar("EnemyData.csv")
    --load in weapon values
    gWeaponTable=LoadChar("WeaponData.csv")
    --load in armor values
    gArmorTable=LoadChar("ArmorData.csv")

    --dofile(GAME_PATH .. "LQ_TempTables.lua")

    --**************************************************************************

    --initialize fonts
    InitFont("font", 1)
    InitFont("font2", 2)

    --CreatePlayerManager
    gGamestate:AddActor(
        PlayerManager({})
    )

    --CreatePlayer
    gGamestate:AddActor(
            Player({
                position = { (((math.floor(gGamestate.screen.w / 2)/ GRID_SIZE) * GRID_SIZE) + (GRID_SIZE / 2)),
                    (((math.floor(gGamestate.screen.h / 2)/ GRID_SIZE) * GRID_SIZE) + (GRID_SIZE / 2))},
            })
    )

        --no longer want to generate random towns
--     for i = 1, NUM_TOWNS do
--         gGamestate:AddActor(
--             Town({
--                 position = GetGrid()
--             })
--         )
--     end
--
--     Add chopper's home base at center of gameplay space.
       gGamestate:AddActor(
            Town({
                --position = {550,450}
                position = { (((math.floor(gGamestate.screen.w / 2)/ GRID_SIZE) * GRID_SIZE) + (GRID_SIZE / 2)),
                    (((math.floor(gGamestate.screen.h / 2)/ GRID_SIZE) * GRID_SIZE) + (GRID_SIZE / 2))},
                })
        )


    --Generate Terrain
    for i = 1,TERRAIN_DENSITY do
        gGamestate:AddActor(
            Terrain({
                position = GetGrid()
            })
        )
    end

    --CreateBackground
    gGamestate:AddActor(
        Background({})
    )


    --Run the game
    EngineLoop()

end

