--==============================================================================
--File:     LuaQuest_Actor
--Author:   Myque Ouellette
--Date:     December 11, 2006
--Descript: All actor objects added to the game
--Note:     Modified and expanded from meteor_shower.lua
--          by Thatcher Ulrich (November 2001)
--Params:   [-width N] [-height N] [-fullscreen]
--==============================================================================


--==============================================================================
--Function: ActorUpdate(self,gs)
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  nothing
--Descript: Updates this actor.  Built to wrap around screen edge
--==============================================================================
function ActorUpdate(self,gs)

    --modded this function to wrap all actors except bullets... bullets are
    --destroyed when the hit the edge of the screen
    local dt = gGamestate.updatePeriod / 1000.0

    --wrap around edge of screen as long as you aren't a bullet
    if self.position.x < -self.radius and self.type ~= "bullet" then
        self.position.x = self.position.x + (gs.screen.w + self.radius * 2)
    end

    if self.position.x > gs.screen.w and self.type ~= "bullet" then
        self.position.x = self.position.x - (gs.screen.w + self.radius * 2)
    end

    if self.position.y < -self.radius and self.type ~= "bullet" then
        self.position.y = self.position.y + (gs.screen.h + self.radius * 2)
    end

    if self.position.y > gs.screen.h and self.type ~= "bullet" then
        self.position.y = self.position.y - (gs.screen.h + self.radius * 2)
    end

    --destroy bullets that leave the screen -- not the most efficient way to
    --do things, but it works for the moment
    if self.position.x < -self.radius and self.type == "bullet" then
        self.active = false
    end

    if self.position.x > gs.screen.w and self.type == "bullet" then
        self.active = false
    end

    if self.position.y < -self.radius and self.type == "bullet" then
        self.active = false
    end

    if self.position.y > gs.screen.h and self.type == "bullet" then
        self.active = false
    end
    
    --handle bombs vanishing after a set period of time
    --if I'm a bomb, and my duration is less than or equal to 0...
    if self.type == "bomb" and self.duration <= 0 then
        --I'm spent... destroy myself
        self.active = false
    --otherwise, if I'm a bomb...
    elseif self.type == "bomb" then
        --take 100 milliseconds off my duration
        self.duration = self.duration - 100
    end

end


--==============================================================================
--Function: ActorRender(self,screen)
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  nothing
--Descript: Draw the actor.  Default blits sprite to screen at position.
--==============================================================================
function ActorRender(self,screen)

    ShowSprite(screen, self.sprite, self.position.x, self.position.y)

end


--==============================================================================
--Function: Actor(t)
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  a (table that can be added to the actors table)
--Descript: Actor Constructor.  Pass in name of sprite bitmap in a table.
--==============================================================================
function Actor(t)

    local a = {}

    --copy elements of t (any pre-defined table elements such as sprite)
    for key,value in t do
        a[key] = value
    end

    a.type = "actor"
    a.active = true
    a.position = vec2(t.position)
    a.velocity = vec2(t.velocity)

    a.radius = a.radius
        or (a.sprite and a.sprite.w * 0.5)
        or 0
    a.update = ActorUpdate
    a.render = ActorRender

    return a

end


--==============================================================================
--Function: ParticleUpdate(self,gs)
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  nothing
--Descript: Updates this particle.  Do linear motion and expire
--==============================================================================
function ParticleUpdate(self,gs)

    local dt = gs.updatePeriod / 1000.0

    --update according to velocity and time
    self.position = self.position + (self.velocity * dt)
    self.countdown = self.countdown - gs.updatePeriod

    --if the countdown time is done, kill ourself
    if self.countdown <= 0 then
        --kill ourself
        self.active = false
    end

end


--==============================================================================
--Function: ParticleRender(self, screen)
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  nothing
--Descript: Draw particle actor.  Default implements sprite to actors position
--==============================================================================
function ParticleRender(self, screen)

    ShowSprite(screen, self.sprite, self.position.x, self.position.y)

end


--shared particle sprite
local gParticleSprite = Sprite("particle")

--==============================================================================
--Function: Particle(t)
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  a (table for addition to actors table)
--Descript: Particle constructor
--==============================================================================
function Particle(t)

    --start with actor defaults
    local a = Actor(t)

    --assign sprite and countdown values
    a.sprite = gParticleSprite
    a.countdown = t.countdown or 500

    --attach particle handlers
    a.update = ParticleUpdate
    a.render = ParticleRender

    return a

end


--global variable storing desired mouse positions
gMouse = {}
--global variable to see if player tried to move and if they moved or not
gPlayerUpdate = 0

--==============================================================================
--Function: PlayerUpdate(self,gs)
--Author:   Myque Ouellette
--Date:     May 24, 2006
--Returns:  nothing
--Descript: Updates the player - uses PlayerMove function to get check 
--          keyboard or mouse input, checks collision and resets player if they
--          are in a solid object
--==============================================================================
function PlayerUpdate(self,gs)

    local colCheck = false

    gPlayerUpdate = 0

    local dt = gs.updatePeriod / 1000.0

    local tempX = self.position.x
    local tempY = self.position.y

    --only do update below if game isn't paused
    if gManager.state == "playing" then

        self.position.x, self.position.y = PlayerMove(self.position.x, self.position.y)

        --check for a collision before updating officially as gMouse will nil out if
        --the player is colliding with terrain
        colCheck = CollisionCheck(self,gs)

        if colCheck == true then
            --revert to previous position
            self.position.x = tempX
            self.position.y = tempY
        end

        --update our position
        ActorUpdate(self,gs)

        --decrement fuel if airborne
        if gPlayer.Landed == false then

            --decrement fuel
            if gPlayer.fuelTimer == 0 then
                --suck down 1 fuel
                gPlayer.fuelPoints = gPlayer.fuelPoints - 1
                --reset fuel timer
                gPlayer.fuelTimer = gPlayer.fuelTimerMax
            --decrement fuel timer by .1 seconds
            else
                gPlayer.fuelTimer = gPlayer.fuelTimer - 100
            end

        end

        --check to see if we're out of fuel... if so, crash.
        if (gPlayer.fuelPoints <= 0) then
            --we crashed... BOOM!
            TempMsg(50, "Out of FUEL! BOOM!", 16, 400, "inf", 1)

            --make the chopper blow up
            newBomb = DropBomb(gPlayer.position.x, gPlayer.position.y)
            gGamestate:AddActor(newBomb)

            --play explosion sound
            Mix_PlayChannel(-1, gSfxBomb, 0)

            --kill the player
            gPlayer.hitPoints = 0
            gPlayer.active = false

            --freeze the game
            gPlayer.paused = true
        end

        --check to see if all armor destroyed... if so, BOOM!
        if (gPlayer.hitPoints <= 0) then
            --we were destroyed... BOOM!
            TempMsg(50, "Torn apart by zombies! BOOM!", 16, 400, "inf", 1)

            --make the chopper blow up
            newBomb = DropBomb(gPlayer.position.x, gPlayer.position.y)
            gGamestate:AddActor(newBomb)

            --play explosion sound
            Mix_PlayChannel(-1, gSfxBomb, 0)

            --kill the player
            gPlayer.active = false

            --freeze the game
            gPlayer.paused = true
        end

    end

end


--==============================================================================
--Function: PlayerMove(x, y, moveX, moveY)
--Author:   Myque Ouellette
--Date:     May 24, 2006
--Returns:  nothing
--Descript: Moves the player and checks for collisions
--==============================================================================
function PlayerMove(x, y)

    --check to see if looking for mouse input or keyboard input (moveX only from keyboard)
    if (gPlayerMoveX == nil and gPlayerMoveY == nil) then  --if no keyboard variables then do mouse

--commented all this out, we don't want mouse movement to work, just keyboard
--         --get mouse position so can move toward it
--         local m = {}
--         m.buttons, m.x, m.y  = SDL_GetMouseState(0,0)
-- 
--         --if there was a click then set position for player to move player
--         if m.buttons("number") ~= 0 then
--             gMouse.x = m.x
--             gMouse.y = m.y
--         end
-- 
--         --check to see if mouse position in the grid is where the player is,
--         --if not, move the player one grid space in the direction of the mouse
-- 
--         if (gMouse.x ~= nil) and (gMouse.y ~= nil) then
--             local mX = math.floor(gMouse.x / GRID_SIZE)
--             local selfX = math.floor(x / GRID_SIZE)
--             local mY = math.floor(gMouse.y / GRID_SIZE)
--             local selfY = math.floor(y / GRID_SIZE)
-- 
--             --check for X
--             if mX ~= selfX then
--                 if mX > selfX then
--                     x = x + GRID_SIZE
--                 elseif mX < selfX then
--                     x = x - GRID_SIZE
--                 end
--                 gPlayerUpdate = 1
--             end
--             --and for Y
--             if mY ~= selfY then
--                 if mY > selfY then
--                     y = y + GRID_SIZE
--                 elseif mY < selfY then
--                     y = y - GRID_SIZE
--                 end
--                 gPlayerUpdate = 1
--             end
--             --clear the mouse variables if the player has reached the destination
--             if mX == selfX and mY == selfY then
--                 gMouse.x = nil
--                 gMouse.y = nil
--             end
--         end

    --otherwise check for keyboard moves
    else

        --check for X
        if gPlayerMoveX == "right" then
            x = x + GRID_SIZE
        elseif gPlayerMoveX == "left" then
            x = x - GRID_SIZE
        end

        --and for Y
        if gPlayerMoveY == "up" then
            y = y - GRID_SIZE
        elseif gPlayerMoveY == "down" then
            y = y + GRID_SIZE
        end

        gPlayerUpdate = 1
        gPlayerMove = nil
        
        --added to clear gPlayerMove after each tick
        gPlayerMoveX = nil
        gPlayerMoveY = nil

    end

    return x, y

end


--==============================================================================
--Function: PlayerRender(self, screen)
--Author:   Myque Ouellette
--Date:     May 24, 2006
--Returns:  nothing
--Descript: Draw player actor.  Default implements sprite to actors position
--==============================================================================
function PlayerRender(self, screen)

    ShowSprite(screen, self.sprite, self.position.x, self.position.y)

end


--==============================================================================
--Function: Player(t)
--Author:   Myque Ouellette
--Date:     May 23, 2006
--Returns:  a (table for addition to actors table)
--Descript: Player constructor
--==============================================================================
function Player(t)

    --start with actor defaults
    local a = Actor(t)

    --initialize score
    a.score = 0

    --assign sprite and type
    a.type = "player"
    a.sprite = Sprite("ChopNorth")

    --assign an initial velocity
    a.Xvelocity = 0
    a.Yvelocity = 0

    --assign a variable to track whether the chopper is airborne or not
    a.Landed = true

    --assign a variable to track whether the game is paused
    a.paused = false

    a.collidable = 1
    a.radius = 0.5 * a.sprite.w

    --set up initial stats and equipment
    --chopper has a max of 10 armor points.
    a.maxHP = 10
    a.hitPoints = a.hitPoints or 10

    --chopper has 50 fuel points to start.
    a.maxFuelPoints = 50
    a.fuelPoints = a.FuelPoints or 50
    a.fuelTimerMax = 10000 --decrement fuel every 10 seconds
    a.fuelTimer = a.fuelTimerMax --initialize fuel timer

    --chopper costs fuel to launch and land
    a.landingCost = 3
    a.launchingCost = 3

    --chopper has 20 bullets to start.
    a.maxBullets = 20
    a.bullets = a.bullets or 20

    --chopper has 5 bombs to start.
    a.maxBombs = 5
    a.bombs = a.bombs or 5

    --chopper is carrying 0 humans to start.
    a.maxHumans = 10
    a.humans = a.humans or 0

    --not used
    a.strength = a.strength or 4
    a.dexterity = a.dexterity or 5
    a.toughness = a.toughness or 5

    a.armor = a.armor or "ChopperArmor"
    a.weapon = a.weapon or "ChopperWeapon"

    a.level = a.level or 1
    --chopper starts with 50 Resource Points.
    a.gold = a.gold or 50

    --chopper specific variables
    a.facing = "N"

    a.name = a.name or "Chopper"

    --attach player handlers
    a.update = PlayerUpdate
    a.render = PlayerRender

    --set global player variable
    if gPlayer.name == nil then
        gPlayer = a
    end

    return a

end

--==============================================================================
--Function: BulletUpdate(self,gs)
--Author:   Eric Bakutis
--Date:     August 28, 2007
--Returns:  nothing
--Descript: Updates a bullet. Tries to keep moving in the direction it was fired.
--==============================================================================
function BulletUpdate(self,gs)

    --how often to update the bullet's position
    local dt = gs.updatePeriod / 1000.0
    local colCheck = false

    --save the bullet's position in case of collision
    tempX = self.position.x
    tempY = self.position.y

    --as long as the game isn't paused
    if gManager.state == "playing" then

        --update the bullet's position based on facing and velocity
        if self.facing == "N" then
            self.position.y = self.position.y - GRID_SIZE
        elseif self.facing == "E" then
            self.position.x = self.position.x + GRID_SIZE
        elseif self.facing == "S" then
            self.position.y = self.position.y + GRID_SIZE
        elseif self.facing == "W" then
            self.position.x = self.position.x - GRID_SIZE
        end
    
        --check for a collision before updating officially as monster should not
        --collide with terrain, towns or player
        colCheck = CollisionCheck(self,gs)
    
        if colCheck == true then
            --destroy self
            self.active = false
    --         --revert to previous position
    --         self.position.x = tempX
    --         self.position.y = tempY
        end
    
        --update our position
        ActorUpdate(self,gs)
    end

end

--==============================================================================
--Function: BombUpdate(self,gs)
--Author:   Eric Bakutis
--Date:     August 28, 2007
--Returns:  nothing
--Descript: Updates a bomb. Makes it explode where it was dropped.
--==============================================================================
function BombUpdate(self,gs)

    --how often to update the bullet's position
    local dt = gs.updatePeriod / 1000.0
    local colCheck = false

    --save the bullet's position in case of collision
    tempX = self.position.x
    tempY = self.position.y

    --as long as the game isn't paused
    if gManager.state == "playing" then

        --check for a collision before updating officially as monster should not
        --collide with terrain, towns or player
        colCheck = CollisionCheck(self,gs)
    
        --all collision is handled in CollisionCheck
    
    --     if colCheck == true then
    --         --destroy self
    --         self.active = false
    -- --         --revert to previous position
    -- --         self.position.x = tempX
    -- --         self.position.y = tempY
    --     end
    
        --update our position
        ActorUpdate(self,gs)

    end

end

--make monsters move only once every 14 seconds by default
MONSTER_MOVE_FREQ = 14000;
--make humans move every 18 seconds by default
HUMAN_MOVE_FREQ = 18000;

--==============================================================================
--Function: TownUpdate(self,gs)
--Author:   Eric Bakutis
--Date:     August 28, 2007
--Returns:  nothing
--Descript: Updates the homebase. Checks if it has been destroyed by zombies.
--==============================================================================
function TownUpdate(self,gs)

    --how often to update the town's position
    local dt = gs.updatePeriod / 1000.0
    local colCheck = false

    --check to see if the homebase has been destroyed--if so, BOOM!
    if (gHomeBase.hitPoints <= 0) then
        --home base was torn apart by zombies
        TempMsg(50, "Home Base destroyed by zombies! BOOM!", 16, 400, "inf", 1)

        --save homebase's position in temp variables so that we can set us
        --up the bomb
        local iOldHomeBaseX = gHomeBase.position.x
        local iOldHomeBaseY = gHomeBase.position.y

        --kill the homebase
        gHomeBase.active = false
        
        --make the homebase blow up
        newBomb = DropBomb(iOldHomeBaseX, iOldHomeBaseY)
        gGamestate:AddActor(newBomb)
        
        --play explosion sound
        Mix_PlayChannel(-1, gSfxBomb, 0)

        --no need to kill the player... let him fly around hopelessly and go
        --eventually go out in a blaze of glory.
    end

end

--==============================================================================
--Function: MonsterUpdate(self,gs)
--Author:   Myque Ouellette
--Date:     May 24, 2006
--Returns:  nothing
--Descript: Updates this monster.  Monster tries to move toward player.
--==============================================================================
function MonsterUpdate(self,gs)

    local dt = gs.updatePeriod / 1000.0
    local colCheck = false

    tempX = self.position.x
    tempY = self.position.y

    --if the player has updated then monster should update too
--     if gPlayerUpdate == 1 then

    --if the player is not in a shop screen the monster should move
    if gPlayer.paused == false and gManager.state == "playing" then

        --comment that out... we want the monsters to move all the time regardless
        --but, we want monsters to move at a slow speed

        --if the monster doesn't have a movetimer, add one
        if self.movetimer == nil then
            self["movetimer"] = 0
        end

        --if the monster's movetimer is 0, it can move
        if self.movetimer == 0 then

            --if the monster hasn't collided with terrain and instigated random
            --movement...
            if self.randommove == false then

                --if the helicopter has landed, walk toward it.
                if gPlayer.Landed == true then
    
                --move the monster one grid space in the direction of the player
    
                    local mX = math.floor(gPlayer.position.x / GRID_SIZE)
                    local selfX = math.floor(self.position.x / GRID_SIZE)
                    local mY = math.floor(gPlayer.position.y / GRID_SIZE)
                    local selfY = math.floor(self.position.y / GRID_SIZE)
        
                    --check for X
                    if mX ~= selfX then
                        if mX > selfX then
                            self.position.x = self.position.x + GRID_SIZE
                        elseif mX < selfX then
                            self.position.x = self.position.x - GRID_SIZE
                        end
                    end
                    --and for Y
                    if mY ~= selfY then
                        if mY > selfY then
                            self.position.y = self.position.y + GRID_SIZE
                        elseif mY < selfY then
                            self.position.y = self.position.y - GRID_SIZE
                        end
                    end
                   
                --wander toward home base
                else
                
                    --get the position of the town
                    local position = {}
                    position["x"] = (((math.floor(gGamestate.screen.w / 2)/ GRID_SIZE) * GRID_SIZE) + (GRID_SIZE / 2))
                    position["y"] = (((math.floor(gGamestate.screen.h / 2)/ GRID_SIZE) * GRID_SIZE) + (GRID_SIZE / 2))
    
                    local mX = math.floor(position.x / GRID_SIZE)
                    local selfX = math.floor(self.position.x / GRID_SIZE)
                    local mY = math.floor(position.y / GRID_SIZE)
                    local selfY = math.floor(self.position.y / GRID_SIZE)
    
                    --check for X
                    if mX ~= selfX then
                        if mX > selfX then
                            self.position.x = self.position.x + GRID_SIZE
                        elseif mX < selfX then
                            self.position.x = self.position.x - GRID_SIZE
                        end
                    end
                    --and for Y
                    if mY ~= selfY then
                        if mY > selfY then
                            self.position.y = self.position.y + GRID_SIZE
                        elseif mY < selfY then
                            self.position.y = self.position.y - GRID_SIZE
                        end
                    end
    
                end
            
            --if the monster has collided with terrain, have it randomly move 
            --in a direction to try to get around the obstacle
            else
                --get a random movement north, east, south or west
                local iRandomMove = math.random(1,4)

                --try a move north
                if iRandomMove == 1 then
                    self.position.y = self.position.y + 50

                --try a move east
                elseif iRandomMove == 2 then
                    self.position.x = self.position.x + 50

                --try amove south
                elseif iRandomMove == 3 then
                    self.position.y = self.position.y - 50

                --try a move west
                elseif iRandomMove == 4 then
                    self.position.x = self.position.x - 50

                end

                --now that we've made a random movement, turn it off again
                --so we can check properly for collision in lines below
                self.randommove = false

            end

            --now reset the monster's movetimer so it doesn't move again for a bit
            if self.speed == "2" then
                --it's a zombie, reset to monster_move_freq
                self.movetimer = MONSTER_MOVE_FREQ
            elseif self.speed == "1" then
                --it's a human, reset to human_move_freq
                self.movetimer = HUMAN_MOVE_FREQ
            end

        else
            --take .1 seconds off the timer
            self.movetimer = self.movetimer - 100
        end

        --end

        --check for a collision before updating officially as monster should not
        --collide with terrain, towns or player
        colCheck = CollisionCheck(self,gs)

        if colCheck == true then
            --revert to previous position
            self.position.x = tempX
            self.position.y = tempY

            --turn on random movement attempts to get around obstacles
            self.randommove = true
        end

        --update our position
        ActorUpdate(self,gs)

    end

end


--==============================================================================
--Function: MonsterRender(self, screen)
--Author:   Myque Ouellette
--Date:     May 24, 2006
--Returns:  nothing
--Descript: Draw Monster.  Default implements sprite to actors position
--==============================================================================
function MonsterRender(self, screen)

    ShowSprite(screen, self.sprite, self.position.x, self.position.y)

end


--==============================================================================
--Function: Monster(t)
--Author:   Myque Ouellette
--Date:     May 23, 2006
--Returns:  a (table for addition to actors table)
--Descript: Monster constructor
--==============================================================================
function Monster(t)

    local a = Actor(t)

    --assign sprite and type
    a.type = "monster"
    a.name = a.name

    a.sprite = Sprite(a.bitmap)

    --set up initial stats and equipment
    a.hitPoints = a.hitPoints
    a.strength = a.strength
    a.dexterity = a.dexterity
    a.toughness = a.toughness

    a.armor = a.armor
    a.weapon = a.weapon
    a.gold = a.gold

    a.collidable = 1
    a.radius = 0.5 * a.sprite.w

    --attach player handlers
    a.update = MonsterUpdate
    a.render = MonsterRender

    --add a boolean to handle getting around terrain when stuck
    a.randommove = false

    return a

end


--==============================================================================
--Function: MonsterGeneratorUpdate(self, gs)
--Author:   Myque Ouellette
--Date:     May 23, 2006
--Returns:  nothing
--Descript: generates a random monster after a given amount of time (up to
--          MAX_MONSTERS)
--==============================================================================
function MonsterGeneratorUpdate(self, gs)
    --if the playermanager is in a paused state then wait
    if gManager.paused == true or gPlayer.paused == true then
        return
    else

        --otherwise countdown and start spawning monsters
    	self.countdown = self.countdown - gs.updatePeriod

        -- timer has expired; spawn a monster
        if self.countdown < 0 then

            --=======================================
            -- function:  MonsterGen (inserted into MonsterGeneratorUpdate)
            -- author:    Eric Bakutis
            -- created:   August 7, 2007
            -- returns:   A random monster created based on player strength
            -- descript:  Generates a random monster with stats based on the stats of the
            --            player and the monster table provided.
            --=======================================
            --add the monster to the master actor list

            --create local variables

            --get length of monster table
            local iMonsterTableLen = table.getn(gEnemyTable)

            --random number in that table
            local iRandomMonsterNum

            --monster picked by random number
            local tRandomMonster

            --random number representing monster modifier (based on player level)
            local iRandomMonsterLevelMod

            --random numbers to use when spawning the monster at a random position
            --resolution of screen
            local iMaxX = gGamestate.screen.w
            local iMaxY = gGamestate.screen.h
            --edge to spawn on (1 = north, 2 = east, 3 = south, 4 = west)
            local iSpawnEdge
            --starting x,y position of monster
            local iSpawnX
            local iSpawnY

            --create a table to hold the monster's spawning position
            local tMonsterPos = {}

            --no further need for this, all zombies and humans are same level
            --set to 1 by default
               local iPlayerLevel = 1
            --get level of player and create range for random monster mods
--             local iPlayerLevel = gPlayer.level
--             local iPlayerLevelLow = iPlayerLevel - 2
--             local iPlayerLevelHigh = iPlayerLevel + 2

            --get the length of the current Gamestate table
            local iTableLength = table.getn(gGamestate.actors)

            --establish active monsters at 0
            local iNumActiveMonsters = 0

            --check through the gamestate table to see how many monster actors we have
            for i = 1, iTableLength do
                if (gGamestate.actors[i].type == "monster") then
                    --found a monster, increment activemonsters by 1
                    iNumActiveMonsters = iNumActiveMonsters + 1
                end
            end

            --if current active monsters <= MAX_MONSTERS then add a monster
            if iNumActiveMonsters < MAX_MONSTERS then

                --get a random monster from the monster table
                iRandomMonsterNum = math.random(1,iMonsterTableLen)

                --grab our random monster from gEnemyTable
                tRandomMonster = gEnemyTable[iRandomMonsterNum]

                --create a new table to hold our tRandomMonster so we don't overwrite
                --Because LUA changes all tables created from a single table as they
                --are changed, we need to use the tempTable function shown in class
                --to create a temporary table that is then inserted into the final
                --table we create from input. We do this because if we just
                --just inserted the table without doing the not-same table
                --function on it first, all entries in the final table would be
                --set to whatever the last change made to table was.
                tTempRandomMonster = {}
                for k,v in tRandomMonster do
                    if type(v) == "table" then
                        for k1, v1 in v do
                            if tTempRandomMonster[k] == nil then
                                tTempRandomMonster[k] = {}
                            end
                            tTempRandomMonster[k][k1] = v1
                        end
                    else
                        tTempRandomMonster[k] = v
                    end
                end

                --no need, no longer doing this since chopper is always the
                --same level

                --get a random amount to add or subtract from monster level
                --iRandomMonsterLevelMod = math.random(iPlayerLevelLow, iPlayerLevelHigh)

                --error checking--make sure we don't have a negative level monster,
                --default to level 1 in that case.
--                 if iRandomMonsterLevelMod < 1 then
--                     iRandomMonsterLevelMod = 1
--                 end

                --increase monster stats based on level
--                 for j = 1, iRandomMonsterLevelMod do
--                     tTempRandomMonster.strength = tTempRandomMonster.strength + 1
--                     tTempRandomMonster.dexterity = tTempRandomMonster.dexterity + 1
--                     tTempRandomMonster.toughness = tTempRandomMonster.toughness + 1
--                     tTempRandomMonster.hitPoints = tTempRandomMonster.hitPoints + 3
--                 end

                --modify gold ONCE based on the monster's level
--                 tTempRandomMonster.gold = tTempRandomMonster.gold * iRandomMonsterLevelMod

                --now we need a random spawning position for the monster.
                --start by getting an edge for the monster to spawn on (N, E, S, or W)
                iSpawnEdge = math.random (1,4)

                --now set starting x and y pos for monster based on map edge
                if (iSpawnEdge == 1) then
                  --spawned on north edge
                  iSpawnX = math.random(1, iMaxX)
                  iSpawnY = 1

                elseif (iSpawnEdge == 2) then
                  --spawned on east edge
                  iSpawnX = iMaxX
                  iSpawnY = math.random(1, iMaxY)

                elseif (iSpawnEdge == 3) then
                  --spawned on south edge
                  iSpawnX = math.random(1, iMaxX)
                  iSpawnY = iMaxY

                elseif (iSpawnEdge == 4) then
                  --spawned on west edge
                  iSpawnX = 1
                  iSpawnY = math.random(1, iMaxY)

                end

                --store the monster's spawning position in a table
                tMonsterPos.x = iSpawnX
                tMonsterPos.y = iSpawnY

                --add the monster's position data to the monster
                tTempRandomMonster.position = tMonsterPos

                --add the monster to LUAQuest
                gGamestate:AddActor(
                    Monster(tTempRandomMonster)
                )

            else

                --give console output telling why a monster wasn't generated
                print("Too many monsters, doing nothing!")

            end

            --end replaced monstergen code
            --**************************************************************************

            --update monster spawning speed based on score
            --check player score and increase monster spawning rate base on score
            if (gPlayer.score <= 500) then
                self.period = 8000
            elseif (gPlayer.score > 500) and (gPlayer.score <= 1000) then
                self.period = 6000
            elseif (gPlayer.score > 1000) and (gPlayer.score <= 2000) then
                self.period = 4000
            elseif (gPlayer.score > 2000) and (gPlayer.score <= 5000) then
                self.period = 2000
            elseif (gPlayer.score > 5000) and (gPlayer.score <= 10000) then
                self.period = 1000
            else
                --end all catch if player's score is above 10000
                self.period = 1000
            end

    		-- reset the timer
    		self.countdown = self.period
    	end
    end
end


--time in ms between monster spawns
BASE_SPAWN_PERIOD = 8000

--==============================================================================
--Function: MonsterGenerator(t)
--Author:   Myque Ouellette
--Date:     May 23, 2006
--Returns:  a (table for addition to actors table)
--Descript: Monster generator constructor
--==============================================================================
function MonsterGenerator(t)

	a = {}
	a.active = 1
	a.type = "MonsterGenerator"
	a.collidable = nil
	a.position = vec2{ 0, 0 }
	a.velocity = vec2{ 0, 0 }
	a.sprite = nil

	a.period = t.period or BASE_SPAWN_PERIOD	-- period, in ms, between spawning monsters
	a.countdown = a.period

    --doesn't render so give blank element
	a.render = function() end
	a.update = MonsterGeneratorUpdate

	return a

end


--==============================================================================
--Function: Town(t)
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  a (table to be added to the actors table)
--Descript: Town constructor
--==============================================================================
function Town(t)

    --start with regular actor
    local a = Actor(t)

    --assign specific keys
    a.type = "town"
    a.collidable = 1
    --load town sprite
    a.sprite = Sprite(gTownSprite)
    a.radius = 0.5 * a.sprite.w

    --give town a name
    a.name = "Home Base"

    --since towns can engage in combat with zombies, give them properties
    a.maxHP = 30
    a.hitPoints = a.maxHP
    a.strength = 5
    a.toughness = 5
    a.dexterity = 5
    
    a.armor = a.armor or "ChopperArmor"
    a.weapon = a.weapon or "ChopperWeapon"

    a.position.x = a.position.x
    a.position.y = a.position.y

    --set global home base variable
    if gHomeBase.name == nil then
        gHomeBase = a
    end

    --set an update to see if the town's been destroyed
	a.update = TownUpdate

    return a

end


--==============================================================================
--Function: TerrainUpdate(self,gs)
--Author:   Eric Bakutis
--Date:     September 12, 2006
--Returns:  nothing
--Descript: Updates the terrain so that when terrain is destroyed, its deleted.
--          No new terrain is created when terrain is destroyed.
--==============================================================================
function TerrainUpdate(self,gs)

    local dt = gs.updatePeriod / 1000.0

    local collide = false

    --check to see if there is collision with anything that can destroy terrain
        collide = CollisionCheck(self, gs)
        --if there is, then destroy the terrain
        if collide == true then
            self.active = false
        end
end


--==============================================================================
--Function: Terrain(t)
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  a (table to be added to the actors table)
--Descript: Terrain Constructor
--==============================================================================
function Terrain(t)

    --start with regular actor
    local a = Actor(t)
    --assign specific keys
    a.type = "terrain"
    a.collidable = 1
    --make sure caller defined one of 3 sizes
    a.size = a.size or math.random(3)
    --load terrain sprite from 3 available
    a.sprite = Sprite(gTerrainSprite[a.size])
    a.radius = 0.5 * a.sprite.w

    --checks for collision and moves (only valid in setup)
    a.update = TerrainUpdate

    return a

end

--==============================================================================
--Function: SavedTerrain(t)
--Author:   Eric Bakutis
--Date:     September 15, 2006
--Returns:  a saved terrain to the actors table
--Descript: Terrain Constructor for save game, receives a terrain position and
--          size from the LoadGame function and creates terrain as appropriate.
--          The original Terrain function creates terrain randomly, hence why
--          I didn't use it.
--==============================================================================
function SavedTerrain(t,savedsize)

    --start with regular actor
    local a = Actor(t)
    --assign specific keys
    a.type = "terrain"
    a.collidable = 1
    --set caller to saved terrain size
    a.size = a.size or savedsize
    --load terrain sprite from 3 available
    a.sprite = Sprite(gTerrainSprite[savedsize])
    a.radius = 0.5 * a.sprite.w

    --checks for collision and moves (only valid in setup)
    a.update = TerrainUpdate

    return a

end


--==============================================================================
--Function: BackgroundRender(self,gs)
--Author:   Myque Ouellette
--Date:     May 26, 2006
--Returns:  nothing
--Descript: Tiles the background sprite across the entire screen
--==============================================================================
function BackgroundRender(self,screen)

    --renders background tile over entire world
    for i = 0, gGamestate.screen.w, self.sprite.w do
        for j = 0, gGamestate.screen.h, self.sprite.h do
            ShowSprite(screen, self.sprite, i, j)
        end
    end

end


--==============================================================================
--Function: Background(t)
--Author:   Myque Ouellette
--Date:     May 26, 2006
--Returns:  a (table to be added to the actors table)
--Descript: Background Constructor
--==============================================================================
function Background(t)

    --start with regular actor
    local a = Actor(t)

    --assign specific keys
    a.type = "background"
    --make sure caller defined one of 3 sizes
    a.sprite = Sprite("background")
    a.radius = 0.5 * a.sprite.w

    --checks for collision and moves (only valid in setup)
    a.render = BackgroundRender

    return a

end


--set global pointer to menu buttons
gMenu = {}

--==============================================================================
--Function: MenuButtonRender(self,screen)
--Author:   Myque Ouellette
--Date:     May 24, 2006
--Returns:  nothing
--Descript: Renders button on screen if visible flag is true
--==============================================================================
function MenuButtonRender(self,screen)
    --if the visible flag is true, render it otherwise don't
    if self.visible == true then

        ShowSprite(screen, self.sprite, self.position.x, self.position.y)

    end

end


--==============================================================================
--Function: MenuButton(t)
--Author:   Myque Ouellette
--Date:     May 24, 2006
--Returns:  a (table to be added to the actors table)
--Descript: Button Constructor
--==============================================================================
function MenuButton(t)

    --start with regular actor
    local a = Actor(t)

    --assign specific keys
    a.type = "menuButton"
    a.name = a.name or ""

    --load sprite
    a.sprite = a.sprite
    a.radius = 0.5 * a.sprite.w
    a.position = a.position

    a.visible = false

    --set render
    a.render = MenuButtonRender

    gMenu[a.name] = {}
    gMenu[a.name] = a

    return a

end


--==============================================================================
--Function: CreateMenuButtons()
--Author:   Myque Ouellette
--Date:     May 24, 2006
--Returns:  gMenu table of menu buttons
--Descript: adds the menu buttons to the actors list
--==============================================================================
function CreateMenuButtons()

    --define game message and button sprites
    --game over
    gGamestate:AddActor(
            MenuButton({
                name = "gameover",
                sprite = Sprite("gameover"),
                position = { (gGamestate.screen.w / 2), (gGamestate.screen.h / 2) }
            })
        )
    --continue
    gGamestate:AddActor(
            MenuButton({
                name = "continue",
                sprite = Sprite("Continue"),
                position = { (gGamestate.screen.w / 2), (gGamestate.screen.h / 2) }
            })
        )
    --help
    gGamestate:AddActor(
            MenuButton({
                name = "help",
                sprite = Sprite("Help"),
                position = { (gGamestate.screen.w / 2), (gGamestate.screen.h / 2) }
            })
        )
    --load game
    gGamestate:AddActor(
            MenuButton({
                name = "load",
                sprite = Sprite("LoadGame"),
                position = { (gGamestate.screen.w / 2), (gGamestate.screen.h / 2) }
            })
        )
    --save game
    gGamestate:AddActor(
            MenuButton({
                name = "save",
                sprite = Sprite("SaveGame"),
                position = { (gGamestate.screen.w / 2), (gGamestate.screen.h / 2) }
            })
        )
    --new game
    gGamestate:AddActor(
            MenuButton({
                name = "new",
                sprite = Sprite("NewGame"),
                position = { (gGamestate.screen.w / 2), (gGamestate.screen.h / 2) }
            })
        )
    --restart
    gGamestate:AddActor(
            MenuButton({
                name = "restart",
                sprite = Sprite("Restart"),
                position = { (gGamestate.screen.w / 2), (gGamestate.screen.h / 2) }
            })
        )
    --quit
    gGamestate:AddActor(
            MenuButton({
                name = "quit",
                sprite = Sprite("Quit"),
                position = { (gGamestate.screen.w / 2), (gGamestate.screen.h / 2) }
            })
        )

    return gMenu
end


--==============================================================================
--Function: CursorUpdate(self, gs)
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  nothing
--Descript: Update the cursor, follow the mouse
--==============================================================================
function CursorUpdate(self, gs)

    --find mouse position and assign i
    local m = {}
    m.buttons, m.x, m.y = SDL_GetMouseState(0, 0)
    self.position.x = m.x
    self.position.y = m.y

    --if buttons isn't 0 the player clicked
    if m.buttons("number") ~= 0 then
        --Checks for collision
        CollisionCheck(self,gs)
    end

end


--==============================================================================
--Function: Cursor(t)
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  a (table representing the mouse cursor)
--Descript: Cursor Constructor
--==============================================================================
function Cursor(t)

    --start with regular actor
    local a = Actor(t)

    --define specific params
    a.type = "cursor"
    a.sprite = Sprite("cursor")
    a.radius = 0.5 * a.sprite.w

    --attach behavior handler
    a.update = CursorUpdate

    return a

end


--==============================================================================
--Function: PlayerManagerUpdate(self, gs)
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  nothing
--Descript: Keep track of game functions (state in particular)
--==============================================================================
function PlayerManagerUpdate(self, gs)

    --if you are in setup mode, look for a mouse click to start
    if self.state == "main" then

        self.countdown = 1000

    elseif self.state == "intro" then

        self.countdown = self.countdown - gGamestate.updatePeriod

        if self.countdown <= 0 then

            self.state = "main"
            self.countdown = 1000

        end

    elseif self.state == "setup" then

        self.countdown = self.countdown - gGamestate.updatePeriod
        if self.countdown <= 0 then
            self.state = "playing"
            self.paused = false
            self.cursor.active = true
        end

    --if playing, then set the cursor to active
    elseif self.state == "playing" then

        self.paused = false

    elseif self.state == "paused" then

        self.paused = true

    elseif self.state == "help" then

        self.paused = true

    elseif self.state == "restart" then

        self.countdown = self.countdown - gGamestate.updatePeriod
        if self.countdown <= 0 then
            Restart()
        end

    end

end


--==============================================================================
--Function: PlayerManagerRender(self, screen)
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  nothing
--Descript: Manages rendering to screen, changes based on state
--==============================================================================
function PlayerManagerRender(self, screen)

    --display main menu
    if self.state == "main" then

        TempMsg(110, "Main Menu", (screen.w / 2) - (gFont[2].charWidth * 4), 100, "inf", 2)
--         TempMsg(110, "New Game", (screen.w / 2) - (gFont[1].charWidth * 4), 200, "inf", 1)
--         TempMsg(110, "Load Game", (screen.w / 2) - (gFont[1].charWidth * 4), 225, "inf", 1)
--         TempMsg(110, "Quit", (screen.w / 2) - (gFont[1].charWidth * 4), 250, "inf", 1)

        --show menu sprites

        --wipe out all hud info and combat spam so can see menu clearly.
        TempMsg(50, "", 0, 0, 0, 1)
        TempMsg(52, "", 0, 0, 0, 1)
        TempMsg(54, "", 0, 0, 0, 1)
        TempMsg(56, "", 0, 0, 0, 1)
        TempMsg(58, "", 0, 0, 0, 1)
        TempMsg(60, "", 0, 0, 0, 1)
        TempMsg(100, "", 0, 0, 0, 1)
        TempMsg(110, "", 0, 0, 0, 1)        

        --new game
        gMenu.new.position.x = (screen.w / 2) - (gMenu.new.sprite.w / 2)
        gMenu.new.position.y = 300
        gMenu.new.visible = true
        --load game
        gMenu.load.position.x = (screen.w / 2) - (gMenu.load.sprite.w / 2)
        gMenu.load.position.y = 350
        gMenu.load.visible = true
        --help
        gMenu.help.position.x = (screen.w / 2) - (gMenu.help.sprite.w / 2)
        gMenu.help.position.y = 400
        gMenu.help.visible = true
        --quit
        gMenu.quit.position.x = (screen.w / 2) - (gMenu.quit.sprite.w / 2)
        gMenu.quit.position.y = 450
        gMenu.quit.visible = true

    --display pause menu
    elseif self.state == "paused" then

        --show paused message
        TempMsg(110, "Paused", (screen.w / 2) - (gFont[2].charWidth * 3), 100, "inf", 2)
--         TempMsg(110, "Continue", (screen.w / 2) - (gFont[1].charWidth * 4), 200, "inf", 1)
--         TempMsg(110, "Restart", (screen.w / 2) - (gFont[1].charWidth * 4), 225, "inf", 1)
--         TempMsg(110, "Save Game", (screen.w / 2) - (gFont[1].charWidth * 4), 250, "inf", 1)
--         TempMsg(110, "Load Game", (screen.w / 2) - (gFont[1].charWidth * 4), 275, "inf", 1)
--         TempMsg(110, "Quit", (screen.w / 2) - (gFont[1].charWidth * 4), 300, "inf", 1)

        --wipe out all hud info and combat spam so can see pause clearly.
        TempMsg(50, "", 0, 0, 0, 1)
        TempMsg(52, "", 0, 0, 0, 1)
        TempMsg(54, "", 0, 0, 0, 1)
        TempMsg(56, "", 0, 0, 0, 1)
        TempMsg(58, "", 0, 0, 0, 1)
        TempMsg(60, "", 0, 0, 0, 1)
        TempMsg(100, "", 0, 0, 0, 1)
        TempMsg(110, "", 0, 0, 0, 1)

        gMenu.new.visible = false

        --continue game
        gMenu.continue.position.x = (screen.w / 2) - (gMenu.continue.sprite.w / 2)
        gMenu.continue.position.y = 250
        gMenu.continue.visible = true
        --restart game
        gMenu.restart.position.x = (screen.w / 2) - (gMenu.restart.sprite.w / 2)
        gMenu.restart.position.y = 300
        gMenu.restart.visible = true
        --save game
        gMenu.save.position.x = (screen.w / 2) - (gMenu.save.sprite.w / 2)
        gMenu.save.position.y = 350
        gMenu.save.visible = true
        --load game
        gMenu.load.position.x = (screen.w / 2) - (gMenu.load.sprite.w / 2)
        gMenu.load.position.y = 400
        gMenu.load.visible = true
        --help
        gMenu.help.position.x = (screen.w / 2) - (gMenu.help.sprite.w / 2)
        gMenu.help.position.y = 450
        gMenu.help.visible = true
        --quit
        gMenu.quit.position.x = (screen.w / 2) - (gMenu.quit.sprite.w / 2)
        gMenu.quit.position.y = 500
        gMenu.quit.visible = true

    --show game title screen
    elseif self.state == "intro" then
    
        ShowSprite(screen, self.title, screen.w / 2, screen.h / 2)
        
    --show game over screen
    elseif gPlayer.active == false and self.state ~= "paused" and self.state ~= "help" and self.state ~= "main" then

        ShowSprite(screen, self.gameover, screen.w / 2, screen.h / 2)

        --wipe out all hud info and combat spam so can see pause clearly.
        TempMsg(50, "", 0, 0, 0, 1)
        TempMsg(52, "", 0, 0, 0, 1)
        TempMsg(54, "", 0, 0, 0, 1)
        TempMsg(56, "", 0, 0, 0, 1)
        TempMsg(58, "", 0, 0, 0, 1)
        TempMsg(60, "", 0, 0, 0, 1)
        TempMsg(100, "", 0, 0, 0, 1)
        TempMsg(110, "", 0, 0, 0, 1)

    --display help information
    elseif self.state == "help" then

        --create local variables to center Help Screen and Help Items
        local helpItemPos = 230
        local helpTitlePos = 380

        --wipe out all hud info and combat spam so can see help screen clearly.
        TempMsg(50, "", 0, 0, 0, 1)
        TempMsg(52, "", 0, 0, 0, 1)
        TempMsg(54, "", 0, 0, 0, 1)
        TempMsg(56, "", 0, 0, 0, 1)
        TempMsg(58, "", 0, 0, 0, 1)
        TempMsg(60, "", 0, 0, 0, 1)
        TempMsg(100, "", 0, 0, 0, 1)

        --show paused message
        --updated to reflect new Choplifter controls
        TempMsg(110, "HELP SCREEN", helpTitlePos, 100, "inf", 2)
        TempMsg(110, "LEFT/RIGHT arrow keys \t Change Chopper facing LEFT/RIGHT", helpItemPos, 200, "inf", 1)
        TempMsg(110, "UP arrow key \t Accelerate (in Facing Direction)", helpItemPos, 225, "inf", 1)
        TempMsg(110, "DOWN arrow key \t Decelerate (opposite Facing Direction)", helpItemPos, 250, "inf", 1)
        TempMsg(110, "RALT \t Fire Bullet (in Facing Direction)", helpItemPos, 275, "inf", 1)
        TempMsg(110, "RCTRL \t Drop a Bomb (below Chopper)", helpItemPos, 300, "inf", 1)
        TempMsg(110, "SPACE \t Launch/Land Chopper", helpItemPos, 325, "inf", 1)
        TempMsg(110, "E \t Open Home Base Shop (must be landed at Home Base)", helpItemPos, 350, "inf", 1)
        TempMsg(110, "S \t Save game", helpItemPos, 375, "inf", 1)
        TempMsg(110, "L \t Load game", helpItemPos, 400, "inf", 1)
        TempMsg(110, "ESC \t Pauses Game (exits typing mode)", helpItemPos, 425, "inf", 1)
        TempMsg(110, "Z \t Takes screenshot", helpItemPos, 450, "inf", 1)
        TempMsg(110, "R \t (in pause screen) Restarts game", helpItemPos, 475, "inf", 1)
        TempMsg(110, "N \t (in main menu) New game", helpItemPos, 500, "inf", 1)
        TempMsg(110, "H \t Brings up this help screen", helpItemPos, 525, "inf", 1)
        TempMsg(110, "[] \t Decrease/Increase music volume", helpItemPos, 550, "inf", 1)
        TempMsg(110, "-= \t Decrease/Increase sound volume", helpItemPos, 575, "inf", 1)

        --clear the menu buttons
        gMenu.new.visible = false
        gMenu.continue.visible = false
        gMenu.restart.visible = false
        gMenu.save.visible = false
        gMenu.load.visible = false
        gMenu.help.visible = false
        gMenu.quit.visible = false
    
    --display's playing HUD information
    elseif self.state == "playing" then

        if (gPlayer.paused == false) then

        TempMsg(110)

            --show gold, player hp, player equipment
            TempMsg(100, "Armor Points: " .. gPlayer.hitPoints .. "/" .. gPlayer.maxHP, 16, screen.h - 150, "inf", 1)
            TempMsg(100, "Fuel: " .. gPlayer.fuelPoints .. "/" .. gPlayer.maxFuelPoints, 16, screen.h - 125, "inf", 1)
            --TempMsg(100, "Gold: " .. gPlayer.gold, 16, screen.h - 125, "inf", 1)
            TempMsg(100, "Bullets: " .. gPlayer.bullets .. "/" .. gPlayer.maxBullets, 16, screen.h - 100, "inf", 1)
            --TempMsg(100, "Level: " .. gPlayer.level, 16, screen.h - 100, "inf", 1)
            TempMsg(100, "Bombs: " .. gPlayer.bombs .. "/" .. gPlayer.maxBombs, 16, screen.h - 75, "inf", 1)
            TempMsg(100, "Humans: " .. gPlayer.humans .. "/" .. gPlayer.maxHumans, 16, screen.h - 50, "inf", 1)
            --TempMsg(100, "Weapon: " .. gPlayer.weapon, 16, screen.h - 75, "inf", 1)
            --TempMsg(100, "Armor: " .. gPlayer.armor, 16, screen.h - 50, "inf", 1)


            --show Resource Points and Base HP in center of screen
            TempMsg(100, "Resource Points: " .. gPlayer.gold, screen.w - 625, screen.h - 425, "inf", 1)
            TempMsg(100, "Base HP:" .. gHomeBase.hitPoints .. "/" .. gHomeBase.maxHP, screen.w - 625, screen.h - 450, "inf", 1)

        elseif (gPlayer.paused == true) then

            --wipe out all hud info and combat spam so can see shop.
            TempMsg(50, "", 0, 0, 0, 1)
            TempMsg(52, "", 0, 0, 0, 1)
            TempMsg(54, "", 0, 0, 0, 1)
            TempMsg(56, "", 0, 0, 0, 1)
            TempMsg(58, "", 0, 0, 0, 1)
            TempMsg(60, "", 0, 0, 0, 1)
            TempMsg(100, "", 0, 0, 0, 1)
            TempMsg(110, "", 0, 0, 0, 1)
            
        end

        --regardless, always show score at top left
        TempMsg(999, "Score: " .. gPlayer.score, 4, 4, "inf", 1)

        --clear the menu buttons
        gMenu.new.visible = false
        gMenu.continue.visible = false
        gMenu.restart.visible = false
        gMenu.save.visible = false
        gMenu.load.visible = false
        gMenu.help.visible = false
        gMenu.quit.visible = false

    end

end


--set the manager variable (that checks if it is active or not)
gManager = nil

--==============================================================================
--Function: PlayerManager(t)
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  a (table representing the main game screen to be added to the actors)
--Descript: Player Manager Constructor
--==============================================================================
function PlayerManager(t)

    local a = {}
    --get any values passed into function
    for key, value in t do
        a[key] = v
    end

    --set up specific variables
    a.type = "Player Manager"
    a.active = true
    a.state = "intro"

    --define cursor
    a.cursor = Cursor({})
    gGamestate:AddActor(a.cursor)

    a.monsterSpawner = gGamestate:AddActor(
                    MonsterGenerator({
                        })
                )

    a.menuButtons = CreateMenuButtons()
    --Choplifter screen
    a.title = Sprite("title2")
    a.gameover = Sprite("gameover")

    a.paused = true
    a.countdown = a.countdown or 2000

    --assign handlers
    a.update = PlayerManagerUpdate
    a.render = PlayerManagerRender

    --setup position info (center of screen, no velocity)
    a.position = { (gGamestate.screen.w /2), (gGamestate.screen.h / 2) }

    --keep global point to player manager for score management
    if not gManager then
        gManager = a
    end

    return a

end
