--==============================================================================
--File:     LuaQuest_Functions
--Author:   Myque Ouellette
--Date:     December 11, 2006
--Descript: Utility functions for LuaQuest
--==============================================================================


--==============================================================================
-- function:  RandomSeedGen
-- author:    Eric Bakutis
-- created:   July 19, 2007
-- returns:   <nil>
-- descript:  Sets up the random seed
--==============================================================================
--This function will seed the random number generator by grabbing the
--current value from the computer's time
function RandomSeedGen()
    --grab the time from the OS and take the Day, Month, Year, Hour, Minute,
    --Second and build them into a number e.g. 7122007104535
    math.randomseed(os.time())

    --start a loop that will run the random function 3 times to 'prime' it
    for i = 1,3 do
        --pick a number between 1 and 10 based on our random seed, priming
        math.random(1,10)
    end

    --tell the user what's just happened, since there's no visual feedback
    print("Random number seeding completed.")

end


--=======================================
-- function:  GetValues
-- author:    Eric Bakutis
-- created:   July 21, 2007
-- returns:   An indexed table with all strings from a line without separators
-- descript:  This function takes all the words out of a string using an
--            optional separator argument (default comma) to puts them into an
--            indexed table.
--=======================================
function GetValues(sString, sSep)

    local iStringLen = string.len(sString) --get the length of the string
    local iStringPos = 1 --the position at which we start searching each loop
    local iStringFound = 1 --the position at which we found a separator
    local sWordFound --the word we found between the separators
    local sepTable = {}  --create a table to hold the words we find in the table
    local iNewTableIndexes = 1 --number of indexes in the newly created table

    --examine sSep to determine what separator the user wants us to use
    --default to a comma if the user enters no value
    if sSep == nil then
        sSep = ","
    end

    --set this to true by default so we can run a loop that will continue
    --checking for seperators until we tell it to stop
    bFindingSeps = true

    --as long as we are still finding separators, run this loop until false
    while bFindingSeps do

        --search the string starting at 1+position the last separator was found
        --(searching starts at 1 and then increments from there)
        iStringFound = string.find(sString, sSep, iStringPos)

            --if the current position we start searching is less than the
            --length of the string AND the value returned is not nil (it will
            --be nil when we reach the end of the string)...
            if iStringPos < iStringLen and iStringFound ~= nil then
                --pull a word out of the string, starting at current iStringPos
                --and going to where we found the separator-1...
                sWordFound = string.sub(sString, iStringPos, iStringFound-1)
                --...and stick this word into a table.
                table.insert(sepTable, sWordFound)
            --if we've reached the end of the string...
            else
                --pull a word out starting at iStringPos and ending at the end
                --of the string--this is the last word and no separator is at
                --the end of it, so we do it differently.
                sWordFound = string.sub(sString, iStringPos, iStringLen)
                table.insert(sepTable, sWordFound)
                --since we know we've reached the end of the string, set 
                --bFindingSeps to false so we can exit our while loop
                bFindingSeps = false
            end

        --after exiting the for loop (assuming we haven't reached the end
        --of the string) set iStringPos = to the position we found the
        --separator at +1, so that next time we search the string, we'll
        --start one character past where we found the final separator
        if iStringFound ~= nil then
            iStringPos = iStringFound + 1
        end

    end

    --let's display the result for the user
    --table.foreach(sepTable,print) -- no need to display for this assignment
    --let's get the number of indexes in the table
    iNewTableIndexes = table.getn(sepTable)

    --now let's return both of these
    return sepTable, iNewTableIndexes

end


--=======================================
-- function:  ReadCSVFile
-- author:    Eric Bakutis
-- created:   July 29, 2007
-- returns:   An indexed table created from a user input text file
-- descript:  Reads in a text file entered by the user and creates an indexed
--            table based on the contents of that text file.
--=======================================
function ReadCSVFile(sFileName)

    --check to make user input a string, cancel function if they didn't
    if type(sFileName) ~= "string" then
        print("Please enter a valid filename (string).")
        return
    end
    --if user input a strinng, we can proceed

    --create a table to hold the values from the file we pass in
    local tReadTable = {}

    --create a string to hold the full file name with path and extension
    local sString = ""

    --set number values to nil to track if we find string results
    local iUserGavePath = nil
    local iUserGaveExt = nil
    local iJunk = nil --use this to blow away the junk second variable

    --create booleans to track the status of string creation
    local bUserGavePath = false
    local bUserGaveExt = false

    --create a default path to attach to the string
    local sDir = "c:\\LuaScripts\\Choplifter\\"

    --create a default extension to attach to the string
    local sExt = ".csv"

    --time to search the user's input string for a path and/or extension
    iUserGavePath, iJunk = string.find(sFileName, ":")
--     print(iUserGavePath)
--     print(iJunk)

    iUserGaveExt, iJunk = string.find(sFileName, "%.")
--     print(iUserGaveExt)
--     print(iJunk)

    --if not nil, we found a path name, so no need to add one
    if type(iUserGavePath) == "number" then
        bUserGavePath = true
    end

    --if not nil, we found a file extension.
    if type(iUserGaveExt) == "number" then
        bUserGaveExt = true
    end

--     print("Before making checks, our finds were as follows:")
--     print(iUserGavePath)
--     print(iUserGaveExt)

    --if we didn't find a path name, we'll need to add one.
    if (bUserGavePath == false) then
        sString = sString .. sDir
    end

--     print("After checking for path, our string was: " .. sString)
--     print(bUserGavePath)
--     print(bUserGaveExt)

    --if we didn't find a path name, we'll need to add one
    if (bUserGaveExt == false) then
        sString = sString .. sFileName .. sExt
    else
        --just need to add the filename itself since it includes extension
        sString = sString .. sFileName
    end

--     print("After checking for extension, our string was: " .. sString)
--     print(bUserGavePath)
--     print(bUserGaveExt)

    --finished adding path and extension as necessary, time to do stuff

    --tries to open a file and store it in variable file
    local file = assert(io.open(sString),"r", "Error: could not open file.")
    --local file = assert(io.open("c:\\LuaScripts\\HeroData.csv"),"r", "Error: could not open file.")
    print("Loaded " .. sString .. " fine!")

    --this sets the default output file to whatever is stored in file--anything
    --that would be tossed to the file instead of the console
    --you have to use this line if you use io.write below
    --io.output(file)

    --set a boolean to true while we are reading values from a text file
    local bReadingValues = true

    --use this to create a line to hold values
    local line

    --reset to the beginning of the file
    file:seek("set")

    --the function below reads each line of the file and then prints it from top to bottom
    while bReadingValues do
        line = file:read() --reads one line by default
        if line ~= nil then
            table.insert(tReadTable,line)
        else
            bReadingValues = false
        end
    end

    local iLength = table.getn(tReadTable)
    table.foreach(tReadTable, print)
    --print("\nNumber of entries in table: " .. iLength - 1)

    --now that we're done reading, close the file.
    file:close()

    return tReadTable, iLength
--
--     for key, value in tReadTable do
--         GetValues(value)
--         print("Done with line " .. key .. "\n")
--     end

end


--=======================================
-- function:  LoadChar
-- author:    Eric Bakutis
-- created:   July 29, 2007
-- returns:   A table of characters created from a user file
-- descript:  Reads in data from a user file, creates a table of characters from that
--            data, then returns the table.
--=======================================
function LoadChar(sString)

    --create some variables to handle our input and such
    local tCharTable = {} --handles raw character data
    local iCharTableLen = nil --handles the length of the table
    local sLine --used to grab the string on each line of a table

    local tNewTable = {} --the new table which stores all our characters
    local iNewTableIndex = nil --the index at which we are importing a new table

    local tNewTableHeaders = {} --handles the headers for new tables created
    local iNumberOfHeaders = nil --number of headers in the table

    local tNewTableData = {} --handles each line of data from the new table
    local tNewTableConc = {} --handles the new table concatenated with the headers
    local iNewTableLen = nil --handles the number of values in each line of the table

    local sTableName

    --First thing we'll do is send the user's string to ReadCSVFile... all
    --necessary error checking for this portion is handled in that func.
    iCharTable, iCharTableLen = ReadCSVFile(sString)

--     PrintTable(iCharTable)

    --Check to see if iCharTableLen is a number... if it isn't, the ReadCSVFile
    --failed and we should go no further.
    if type(iCharTableLen) ~= "number" then
        print("Because I could not find the file you entered, terminating function.")
        return
    end

    --table.foreach(iCharTable,print)
    --print("Function proceeds from here.")
    
    --now that we've got a good table, it's time to create new index tables for
    --each entry in the .csv file.
    for i = 1, iCharTableLen do
        
        --We are on the first line of our inputted table, which has headers
        if (i == 1) then
            line = iCharTable[i]
            --put the headers into their own table and get the number of headers
            tNewTableHeaders, iNumberOfHeaders = GetValues(line)

        --now that we've got our header data, we can create the rest of our tables
        else
            --sTableName = "tNewTableConc" .. i

            --sTableName = {}

            --first we'll get the line of input we're playing with
            --print(i)
            line = iCharTable[i]
            --print(line)
            --and then convert it into a table
            tNewTableData, iNewTableLen = GetValues(line)
            --print(iNumberOfHeaders)

            --now we'll put the table together with the headers
            for j = 1, iNumberOfHeaders do
                tNewTableConc[tNewTableHeaders[j]] = tNewTableData[j]
            end

            --Because LUA changes all tables created from a single table as they
            --are changed, we need to use the tempTable function shown in class
            --to create a temporary table that is then inserted into the final
            --table we create from input. We do this because if we just
            --just inserted tNewTableConc without doing the not-same table
            --function on it first, all entries in the final table would be
            --set to whatever the last change made to tNewConcTable was.
            tempTable = {}
            for k,v in tNewTableConc do
                if type(v) == "table" then
                    for k1, v1 in v do
                        if tempTable[k] == nil then
                            tempTable[k] = {}
                        end
                        tempTable[k][k1] = v1
                    end
                else
                    tempTable[k] = v
                end
            end

            --now that we've safely created a new temporary table from the
            --table we created, we can insert that in our final table without
            --worrying about later versions of tNewContTable replacing the
            --earlier versions.
            table.insert(tNewTable, tempTable)
        end
    end

    --thus we end up with a single indexed table of dictionary tables with
    --headers based on the first line of the input file and those headers
    --assigned to values from all subsequent lines. Pretty slick.

    --Print the table so the user can view what happened
    --PrintTable(tNewTable)
    
    --return the table to the calling function
    return(tNewTable)

end


--==============================================================================
-- function:  ParseSaveData(myString)
-- author:    Myque Ouellette
-- created:   May 22, 2006
-- returns:   table
-- descript:  Takes table loaded from save game and parses through it to create
--            usable data table
--==============================================================================
function ParseSaveData(myFileName)

    local tGiantTable = ReadCSVFile(myFileName)

    return tGiantTable

end


--==============================================================================
--Function: SortPriority()
--Author:   Myque Ouellette
--Date:     July 26, 2006
--Returns:  nothing
--Descript: Sorts table elements in priority order of their type
--==============================================================================
function SortPriority()

    --**************************************************************************
    --placeholder code (to be replaced)
    -- TEB
    --leaving this code in place so it will add new actors as necessary
    for k,v in gGamestate.actors do
        --if the actor is active then add to newActors list
        if v.active then
            if v.type == "background" then
                table.insert(gGamestate.newActors, 1, v)
            else
                table.insert(gGamestate.newActors, v)
            end
        end
    end

    --=======================================
    -- function:  SortOrder
    -- author:    Eric Bakutis
    -- created:   August 7, 2007
    -- returns:   The things displayed in the game sorted properly
    -- descript:  This function reorders the gamestate table so that everything
    --            is displayed in the proper order. It uses the table tSortOrder
    --            to determine how to sort, see top of this code for the
    --            tSortOrder table.
    --=======================================

    --once all new actors are added, time to reorder the table. We will sort
    --gGamestate.newActors since that's what going into gGamestate.actors
    --at the end of this function. We use the global gSortOrder to determine
    --how we sort... this table is specified in LQ_Init.lua

    --get length of current gamestate table so we know how long new one will be
    local tCurGamestateLength = table.getn(gGamestate.newActors)
    --get a table we can increment through
    local tOldGamestateTable = gGamestate.newActors

    --get our sorting table so we know how many sorts we have and what each
    --one is named
    local iNumSorts = table.getn(gSortOrder)

    --get name of first item to order in the new table
    local sType

    --get the name of the ordered item's type so we can search for substrings
    local sValue

    --tell the function if we found the substring or didn't
    local iFoundString = nil
    local iJunk = 0

    --create a new table to replace the current Gamestate table
    local gNewGamestate = {}

    --run through the current gamestate table once for each type of value
    --we need to sort
    for j = 1,iNumSorts do

        --set the name of the first item we're going to order
        sType = gSortOrder[j]

        --now run through current gamestate table and assign appropriate order
        for i = 1,tCurGamestateLength do

            --set sValue to a string equal to the type of the sorted value
            sValue = tOldGamestateTable[i].type

            --set iFoundString to a number if we find substring in the value,
            --else it's nil and we don't do anything
            iFoundString, iJunk = string.find(sValue, sType)

            --if the found the type of value we're sorting (stype) in the value
            --we're checking (sValue), add this value to the new table
            if (iFoundString ~= nil) then
                table.insert(gNewGamestate, tOldGamestateTable[i])
            end

            --reset iFoundString to nil for the next loop
            iFoundString = nil

        --else, add nothing.
        end

    --finished sorting properly, let's update gGamestate.newActors
    gGamestate.newActors = gNewGamestate
    end
    --all code below this line is original code in LUAQuest
    --==========================================

    --make actors the newActors list (has only active in it)
    gGamestate.actors = gGamestate.newActors
    --reset newActors table
    gGamestate.newActors = {}
    --end placeholder code
    --**************************************************************************

end


--==============================================================================
-- function:  SaveGame()
-- author:    Myque Ouellette
-- created:   May 22, 2006
-- returns:   <nil>
-- descript:  Saves the game
--==============================================================================
function SaveGame(tempInput)

    --need to search gGamestate and pull out actors that we want to save

    --search through gGamestate.actors four times, picking up first the player,
    --then the town, then the monsters, then finally terrain. We will not save
    --bullets or bombs because they exist for such a short period of time. We
    --do the search four times to guarantee our output is saved in the same
    --order every time.

    --all of this output is printed to the savegame.txt due to the lines below
    for search = 1,4 do

        --search gGamestate.actors for tables we need to save
        for indx = 1,table.getn(gGamestate.actors) do
            local a = gGamestate.actors[indx]

            --if we found a player, save that player's properties
            if a.type == "player" and search == 1 then

                --tries to open testfile.txt and store it in file... if it
                --doesn't exist, create testfile.txt and store it in file
                --opens a file for writing--if the file doesn't exist, you're
                --creating a filename you want to use
                --since this is the first time we opened the file, we'll
                --use write mode--all other times we will use append mode
                local file = assert(io.open("c:\\LuaScripts\\Choplifter\\savegame.txt","w"), "Error: could not open file.")
                --first paramenter is file name, second parameter is what mode
                --you want to put it in.... -r read, -w write, -a append

                io.output(file) --this sets the default output file to whatever
                --is stored in file--anything that would be tossed to the file
                --instead of the console
                --you have to use the above line if you use io.write below

                --print("--Player")
                file:write("--Player" .. "\n")
                --we know we found a player, now close the file
                file:close()
                --now write the player's data
                PrintSaveGameData(a)

            --if we found a town, save that town's properties
            elseif a.type == "town" and search == 2 then

                --tries to open testfile.txt and store it in file... if it
                --doesn't exist, create testfile.txt and store it in file
                --opens a file for writing--if the file doesn't exist, you're
                --creating a filename you want to use
                local file = assert(io.open("c:\\LuaScripts\\Choplifter\\savegame.txt","a"), "Error: could not open file.")
                --first paramenter is file name, second parameter is what mode
                --you want to put it in.... -r read, -w write, -a append

                io.output(file) --this sets the default output file to whatever
                --is stored in file--anything that would be tossed to the file
                --instead of the console
                --you have to use the above line if you use io.write below

                --print("--Town")
                file:write("--Town" .. "\n")
                --we know we found a town, now close the file
                file:close()
                --now write the towns's data
                PrintSaveGameData(a)

            --if we found a monster, save that monster's properties
            elseif a.type == "monster" and search == 3 then

                --tries to open testfile.txt and store it in file... if it
                --doesn't exist, create testfile.txt and store it in file
                --opens a file for writing--if the file doesn't exist, you're
                --creating a filename you want to use
                local file = assert(io.open("c:\\LuaScripts\\Choplifter\\savegame.txt","a"), "Error: could not open file.")
                --first paramenter is file name, second parameter is what mode
                --you want to put it in.... -r read, -w write, -a append

                io.output(file) --this sets the default output file to whatever
                --is stored in file--anything that would be tossed to the file
                --instead of the console
                --you have to use the above line if you use io.write below

                --print("--Monster")
                file:write("--Monster" .. "\n")
                --we know we found a monster, now close the file
                file:close()
                --now write the monsters's data
                PrintSaveGameData(a)

            --if we found a terrain, save that terrain's properties
            elseif a.type == "terrain" and search == 4 then

                --tries to open testfile.txt and store it in file... if it
                --doesn't exist, create testfile.txt and store it in file
                --opens a file for writing--if the file doesn't exist, you're
                --creating a filename you want to use
                local file = assert(io.open("c:\\LuaScripts\\Choplifter\\savegame.txt","a"), "Error: could not open file.")
                --first paramenter is file name, second parameter is what mode
                --you want to put it in.... -r read, -w write, -a append

                io.output(file) --this sets the default output file to whatever
                --is stored in file--anything that would be tossed to the file
                --instead of the console
                --you have to use the above line if you use io.write below

                --print("--Terrain")
                file:write("--Terrain" .. "\n")
                --we know we found a terrain, now close the file
                file:close()
                --now write the terrain's data
                PrintSaveGameData(a)
                
            end

        end

    end

--         file:write("Testline " .. index .. "\n")   --write a line to the text file
--         --io.write(file, "Testline " .. index .. "\n")  --same thing, but a longer version
--     end
--
     --file:close()  --always have to use this to close a file or memory address stays open

     --send output to the console telling the user the game was saved
     print("Game saved.")

        --PrintTable(gGamestate.actors)

end


--create a global loading flag so if loading, properdata input
gLoadGame = nil
gLoadTable = {}

--==============================================================================
-- function:  LoadGame(fileName)
-- author:    Myque Ouellette
-- created:   May 22, 2006
-- returns:   <nil>
-- descript:  Loads the game from a save
--==============================================================================
function LoadGame(fileName)

    --when loading a game, first thing we have to do is check for a valid
    --savegame file... if no savegame file exists, there's nothing to load and
    --we should do nothing

    --check for savegame

    --now that we know we have a savegame file, we need to wipe out EVERYTHING
    --currently in the game... monsters, terrain, bullets, and bombs. We'll
    --keep the player and town since there is always only one of each and we
    --can simply update their properties instead of deleting and re-adding
    --then. We are going to wipe out everything else to replace it with saved
    --game data.

    --search through gGamestate.actors to find all things we need to delete
    for indx = 1,table.getn(gGamestate.actors) do
        local a = gGamestate.actors[indx]

        --if the actor is a monster, terrain, or bullet...
        if a.type == "monster" or a.type == "terrain" or a.type == "bullet" or a.type == "bomb" then
            --delete it... we are going to replace all of these anyway
            a.active = false
        end

    end

    --now that we've wiped the area clean of monsters, terrain, bullets, and
    --bombs, we need to add all the new actors from our savegame to the
    --gamefield.

    --update the player's stats from savegame... only 1 player, so we can do
    --this easy.

    --track the number of monsters loaded for debugging
    local iMonstersLoaded = 0
    
    --track the index of the monster we're loading to prevent double loads
    local iSavedMonsterIndex
    
    --track the index of the terrain we're loading to prevent double loads
    local iSavedTerrainIndex

    --get the save game data
    local tSavedData = ParseSaveData("C:\\LuaScripts\\Choplifter\\savegame.txt")

    --see how big our saved data table is
    local iSavedDataLen = table.getn(tSavedData)

    --now set the saved item we're updating
    local sSavedItem

    --now create a string line for comparison and it's length
    local line
    local linelen

    --now create some values to hold key and value
    local sKey
    local sValue

    --now create a table to hold position data for monsters and terrain
    local tPos = {}

    --now create a temporary string to hold specific data about the saved item
    local sItemType

    --now create a boolean to tell the loadgame whether it has enough data to
    --add a monster or terrain
    local bReadyToAdd = false

    --now move through the saved data to update player, town, monsters, and
    --terrain
    for index = 1, iSavedDataLen do

        --set line to the string we're examining and it's length to length
        line = tSavedData[index]
        --print("Line is " .. line)
        linelen = string.len(line)
        --print("Line length is " .. linelen)
        
        --clear sKey and sValue at the start of each run
        sKey = nil
        sValue = nil

        --first update what saved item we're loading, that affects what we do.
        if line == "--Player" then
            --we're loading a player, update
            sSavedItem = "player"
            print("Found a player")
        elseif line == "--Town" then
            --we're updating a town, update
            sSavedItem = "town"
            print("Found a town")
        elseif line == "--Monster" then
            --we're updating a monster, update
            sSavedItem = "monster"
            print("Found a monster")
            --set bReadyToAdd to false because we've found a new monster, we
            --don't want to add that monster until we've parsed all the data
            bReadyToAdd = false
        elseif line == "--Terrain" then
            --we're updating a terrain, update
            sSavedItem = "terrain"
            print("Found a terrain")
            --set bReadyToAdd to false because we've found a new terrain, we
            --don't want to add that terrain until we've parsed all the data
            bReadyToAdd = false
        end

        --set iEqualStart and End to nil by default
        local iEqualStart = nil
        local iEqualEnd = nil

        --now parse the line so that we can work with it's values... find =
        iEqualStart, iEqualEnd = string.find(line,"=")

        --now, assuming the line HAD an = (and wasn't a comment) let's split
        --it up into workable parts
        if iEqualStart ~= nil then

            sKey = string.sub(line,1,(iEqualStart-1))
            --print("sKey is " .. sKey)
            sValue = string.sub(line,(iEqualStart+1),linelen)
            --print("sValue is " .. sValue)

        end

        --now update accordingly
        if sSavedItem == "player" then

            --if sKey ~= nil and sValue ~= nil then
                --print("Updating the player, key = " .. sKey .. " and value = " .. sValue .. ".")
            --end

            --only make changes to the proper data
            if sKey == "x" then
                gPlayer.position.x = tonumber(sValue)
            elseif sKey == "y" then
                gPlayer.position.y = tonumber(sValue)
            elseif sKey == "score" then
                gPlayer.score = tonumber(sValue)
            elseif sKey == "fuelPoints" then
                gPlayer.fuelPoints = tonumber(sValue)
            elseif sKey == "Xvelocity" then
                gPlayer.XVelocity = tonumber(sValue)
            elseif sKey == "Yvelocity" then
                gPlayer.YVelocity = tonumber(sValue)
            elseif sKey == "hitPoints" then
                gPlayer.hitPoints = tonumber(sValue)
            elseif sKey == "bullets" then
                gPlayer.bullets = tonumber(sValue)
            elseif sKey == "humans" then
                gPlayer.humans = tonumber(sValue)
            elseif sKey == "Landed" and sValue == "false" then
                gPlayer.Landed = false
            elseif sKey == "Landed" and sValue == "true" then
                gPlayer.Landed = true
            elseif sKey == "gold" then
                gPlayer.gold = tonumber(sValue)
            elseif sKey == "facing" then
                gPlayer.facing = sValue
            elseif sKey == "bombs" then
                gPlayer.bombs = tonumber(sValue)
                
                --now that we've finished updating the player, let's update his
                --sprite so players know what's going on.

                if gPlayer.Landed == true then

                    --swap the chopper to a sprite without blades moving
                    if gPlayer.facing == "N" then
                        gPlayer.sprite = Sprite("ChopNorth")
                    elseif gPlayer.facing == "E" then
                        gPlayer.sprite = Sprite("ChopEast")
                    elseif gPlayer.facing == "S" then
                        gPlayer.sprite = Sprite("ChopSouth")
                    elseif gPlayer.facing == "W" then
                        gPlayer.sprite = Sprite("ChopWest")
                    end
                
                else

                    --swap the chopper to a sprite with blades moving
                    if gPlayer.facing == "N" then
                        gPlayer.sprite = Sprite("ChopAirNorth")
                    elseif gPlayer.facing == "E" then
                        gPlayer.sprite = Sprite("ChopAirEast")
                    elseif gPlayer.facing == "S" then
                        gPlayer.sprite = Sprite("ChopAirSouth")
                    elseif gPlayer.facing == "W" then
                        gPlayer.sprite = Sprite("ChopAirWest")
                    end

                end

                --and finally update the chopper
                ActorUpdate(gPlayer,gGamestate)

            end

        elseif sSavedItem == "town" then

            --only make changes to the proper data
            --never need to update position of town, it's always the same
            --now update the town's stats on the game field... only 1 town, so this
            --is easy
            if sKey == "hitPoints" then
                gHomeBase.hitPoints = tonumber(sValue)
            end

        elseif sSavedItem == "monster" then
            --only make changes to the proper data

            --get saved monster data
            if sKey == "y" then
                tPos.y = tonumber(sValue)
            elseif sKey == "x" then
                tPos.x = tonumber(sValue)
            elseif sKey == "name" then
                --this will be "Human" or "Zombie"
                sItemType = sValue
            elseif sKey == "type" then
                --we've imported all necessary monster save for the previous
                --monster, time to generate a monster
                bReadyToAdd = true
            end

            --we will only do the code enclosed below if bReadyToAdd has been
            --set to true, which it will only be after we have read in all
            --necessary save data.
            if bReadyToAdd == true then

                --create a table for our new monster
                local tSavedMonster = {}

                --now create a new monster based on sItemType
                if sItemType == "Human" then
                    tSavedMonster = gEnemyTable[2]
                elseif sItemType == "Zombie" then
                    tSavedMonster = gEnemyTable[1]
                end

                --create a new table to hold our tRandomMonster so we don't overwrite
                --Because LUA changes all tables created from a single table as they
                --are changed, we need to use the tempTable function shown in class
                --to create a temporary table that is then inserted into the final
                --table we create from input. We do this because if we just
                --just inserted the table without doing the not-same table
                --function on it first, all entries in the final table would be
                --set to whatever the last change made to table was.
                tTempMonster = {}
                    for k,v in tSavedMonster do
                        if type(v) == "table" then
                            for k1, v1 in v do
                                if tTempMonster[k] == nil then
                                    tTempMonster[k] = {}
                                end
                                tTempMonster[k][k1] = v1
                            end
                        else
                            tTempMonster[k] = v
                        end
                    end

                --add the monster's saved position data to the monster
                tTempMonster.position = tPos

                --add the saved monster to LUAQuest
                gGamestate:AddActor(
                    Monster(tTempMonster)
                )
                
                --reset to false so we only do each add once
                bReadyToAdd = false
                
                iMonstersLoaded = iMonstersLoaded + 1
                print(tostring(iMonstersLoaded) .. " monsters loaded.")

            end

        elseif sSavedItem == "terrain" then
            --only make changes to the proper data

            --get saved terrain data
            if sKey == "y" then
                tPos.y = tonumber(sValue)
            elseif sKey == "x" then
                tPos.x = tonumber(sValue)
            elseif sKey == "size" then
                --set the terrain size from save
                sItemType = tonumber(sValue)
                --now we've imported all necessary monster save for the
                --previous terrain, time to generate a terrain
                bReadyToAdd = true
            end

            --we will only do the code enclosed below if bReadyToAdd has been
            --set to true, which it will only be after we have read in all
            --necessary save data.
            if bReadyToAdd == true then

                --create a table for our new terrain
                local tSavedTerrain = {}

                --now create a new terrain based on sItemType, which will be
                --1, 2, or 3 drawn from size
                --tSavedTerrain.sprite = Sprite(gTerrainSprite[size])
                --tSavedTerrain.radius = 0.5 * a.sprite.w

                --create a new table to hold our tRandomMonster so we don't overwrite
                --Because LUA changes all tables created from a single table as they
                --are changed, we need to use the tempTable function shown in class
                --to create a temporary table that is then inserted into the final
                --table we create from input. We do this because if we just
                --just inserted the table without doing the not-same table
                --function on it first, all entries in the final table would be
                --set to whatever the last change made to table was.
                tTempTerrain = {}
                    for k,v in tSavedTerrain do
                        if type(v) == "table" then
                            for k1, v1 in v do
                                if tTempTerrain[k] == nil then
                                    tTempTerrain[k] = {}
                                end
                                tTempTerrain[k][k1] = v1
                            end
                        else
                            tTempTerrain[k] = v
                        end
                    end

                --add the terrain's saved position data to the terrain
                tTempTerrain.position = tPos

                --add the terrain to LUAQuest--using our custom function 
                --since the type of terrain is NOT random, but saved
                gGamestate:AddActor(
                    SavedTerrain(tTempTerrain,sItemType)
                )
                
                --reset to false so we only do each add once
                bReadyToAdd = false

            end
        end
    
    end

    --now that we've added all saved actors to the gamestate, let's resume the
    --game
    if gManager.state == "paused" then
        gManager.state = "playing"
    end

end


--=======================================
-- function:  PrintSaveGameData
-- author:    Eric Bakutis
-- created:   September 10, 2007
-- returns:   n/a
-- descript:  Print selected content from gGamestate.actors. We use this to
--            print the data we want to write to our savegame txt file.
--=======================================
function PrintSaveGameData(tTableName)

    --tries to open savegame.txt and store data in file... we want to open in
    --append mode because we are adding to an existing file
    --opens a file for writing--if the file doesn't exist, you're creating a filename you want to use
    local file = assert(io.open("c:\\LuaScripts\\Choplifter\\savegame.txt","a"), "Error: could not open file.")
    --first paramenter is file name, second parameter is what mode  you want 
    --to put it in.... -r read mode, -w write mode, -a append mode

    --this sets the default output file to whatever is stored in
    --file--anything that would be tossed to the file instead of the console
    --you have to use the above line if you use io.write below
    io.output(file)

    --now let's iterate through the table above, this prints all values and
    --tables within the table
    for key,value in tTableName do

        --the code below actually iterates through the table printing values
        --and values within tables until all tables are printed
        --don't print any part of the actor that is a function, don't need
        if type(value) == "function" then
            --print("\t" .. key .. " is a function. Not printing it.")
        --we'll grab everything else, strings, numbers and booleans
        elseif type(value) == "table" then
            --do not worry about velocity or sprite, we need neither in our
            --save game data info
            if key ~= "velocity" and key ~= "sprite" then
            --print(key)
                --print("--" .. key)
                --print the value and a seperator character ,
                PrintSaveGameData(value)
            end
        else
            --we only want specific data for our savegame... we're going to
            --save the selected data ONLY for efficiency
            --player save data
            if key == "score" or
               key == "fuelPoints" or
               key == "Xvelocity" or
               key == "Yvelocity" or
               key == "x" or
               key == "y" or
               key == "hitPoints" or
               key == "bullets" or
               key == "humans" or
               key == "Landed" or
               key == "gold" or
               key == "facing" or
               key == "bombs" or
               key == "type" or
               key == "name" or
            --town save data
                --none, already have hitpoints, x and y
            --monster save data
                --none, already have hitpoints, type, name, x and y
            --terrain save data
                key == "size"
                then
            --print the key, value and a seperator character ,
            local tempkey = tostring(key)
            local tempvalue = tostring(value)
            file:write(tempkey .. "=" .. tempvalue .. "\n")
            --print(key, value, ",")
            end
        end
    end
    
    --now that we're done saving, close the file
    file:close()

end
