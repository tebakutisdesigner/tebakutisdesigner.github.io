--==============================================================================
--File:     LuaQuest_Core
--Author:   Myque Ouellette
--Date:     December 11, 2006
--Descript: Core functions to run the engine - includes setup
--==============================================================================


--==============================================================================
--Author:   Myque Ouellette
--Date:     May 1, 2006
--Descript: Example Game
--Note:     Initial setup and directory checking
--==============================================================================

--initialize SDL, if it fails then give error
if SDL.Init(SDL_INIT_VIDEO .. SDL_INIT_AUDIO) ~= 0 then
    print("Unable to initialize SDL: ", SDL_GetError())
end

--set up gamestate table
gGamestate = {
    lastUpdateTicks = 0,
    beginTime = 0,
    elapsedTicks = 0,
    frames = 0,

    updatePeriod = 30, --interval between calls to UpdateTick()
    active = true,

    screen = nil,
    background = nil,

    newActors = {},
    actors = {},
    AddActor = function(self,a)
                   assert(a)
                   --whenever an actor is added it sets flag to re-sort
                   gActorSorted = false
                   table.insert(self.newActors,a)
               end
}

--create an SDL blit surface
SDL.SDL_BlitSurface = SDL.SDL_UpperBlit

--create a cache for pre-loaded sprites to maximize sharing
local gSpriteCache = {}

--==============================================================================
--Function: Sprite
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  mySprite
--Descript: Constructs sprites, passes in bitmap filename, returns SDL surface
--          which is ready to be blitted
--==============================================================================
function Sprite(file)

    --check to see if the sprite is already in the cache (already been loaded)
    --if so, then return it (otherwise we'll load it in)
    if gSpriteCache[file] then
        return gSpriteCache[file]
    end

    --bitmaps can be in bmp or png format (support could be extended if desired)
    local ext = ".bmp"

    --check to see if can find the file, if not then return an error
    if not fExists(GAME_PATH .. file .. ext) then
        ext = ".png"
        if not fExists(GAME_PATH .. file .. ext) then
            error("Unknown filename '" .. file .. "'!")
        end
    end

    --load the sprite image
    local mySprite = SDL_LoadBMP(GAME_PATH .. file .. ext)

    --if didn't load properly, output an error
    if mySprite == nil then
        print("Could not load " .. file .. ext ..": " .. SDL_GetError())
        return nil
    end

    --set transparent color to black
    --(change SDL_MapRGB to the color you would like transparent)
    transColor = SDL_MapRGB(mySprite.format, 0, 0, 0)
    transColor = tonumber(transColor,16)
    mySprite:SetColorKey(SDL.SDL_SRCCOLORKEY .. SDL.SDL_RLEACCEL, SDL_Color(transColor))

    --convert sprite to video SDL format
    mySprite = mySprite:DisplayFormat()

    --if it didn't convert then error
    if mySprite == nil then
        print("Couldn't convert background: " .. SDL_GetError())
        return nil
    end

    --add sprite to cache
    gSpriteCache[file] = mySprite
    return mySprite

end


--==============================================================================
--Function: ShowSprite
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  mySprite
--Descript: Takes a sprite and draws in on screen
--          at the given coordinates
--==============================================================================
function ShowSprite(screen, sprite, x, y, src)

    --make sure we have a temporary rect surface
    if gTempRect == nil then
        gTempRect = SDL_Rect()
    end

    --define tempRect position and size
    gTempRect.x = x - sprite.w / 2
    gTempRect.y = y - sprite.h / 2
    gTempRect.w = sprite.w
    gTempRect.h = sprite.h

    --display on screen
    SDL_BlitSurface(sprite, src, screen, gTempRect)

end


--==============================================================================
-- function:  DrawFont(screen, image, x, y, w, h, x2, y2)
-- author:    Myque Ouellette
-- created:   May 2, 2006
-- returns:   <nil>
-- descript:  blits surface for drawing font
--==============================================================================
function DrawFont(screen, image, x, y, w, h, x2, y2)

    --create a rect for the draw position of the font
    gDest = SDL_Rect()
    gDest.x = x
    gDest.y = y

    --create a rect that looks for the specific letter in the bitmap
    gSrc = SDL_Rect()
    gSrc.x = x2
    gSrc.y = y2
    gSrc.w = w
    gSrc.h = h

    --display on screen
    SDL_BlitSurface(image, gSrc, screen, gDest)

end


--Define the font table
gFont = {}

--==============================================================================
-- function:  InitFont(fontName)
-- author:    Myque Ouellette
-- created:   May 2, 2006
-- returns:   gFont[i] -- the font table for that font
-- descript:  Loads font into memory
--==============================================================================
function InitFont(fontName, fontNum)

    --check to make sure fonts are valid
    if fontName == nil then
        print("Error.  Please enter the name of the font bitmap file to load.")
        os.exit()
    end
    --check to make sure they assigned a font number to the font
    if fontNum == nil then
        print("Error! Please enter the number position of the font.")
        os.exit()
    end

    --set up font as index fontNum in the global font table
    gFont[fontNum] = {}
    --assign sprite
    gFont[fontNum].type = "font"
    gFont[fontNum].font = Sprite(fontName)
    --check to make sure font loaded
    if gFont[fontNum].font == nil then
        print("Error loading font file: " .. SDL_GetError() .. ".\n")
    end

    --set up font params
    gFont[fontNum].charWidth = gFont[fontNum].font.w / 16    --All characters are 16x16 in bmp

end


--==============================================================================
-- function:  StringTable(str)
-- author:    Myque Ouellette
-- created:   May 2, 2006
-- returns:   table (one character in string for each index)
-- descript:  Takes a given string and loads each character into a table for rendering later
--==============================================================================
function StringTable(str)

    --finds length of string and defines empty table
    local len = string.len(str)
    local strTbl = {}

    --go through each character in the string and put it in its own index in the table
    for i = 1, len do
        strTbl[i] = string.sub(str, i, i)
    end

    --return the table
    return strTbl

end


--==============================================================================
-- function:  MessageUpdate(self,gs)
-- author:    Myque Ouellette
-- created:   May 2, 2006
-- returns:   nothing
-- descript:  Updates the message on screen
--==============================================================================
function MessageUpdate(self,gs)

    --if countdown is nil then display indefinitely, otherwise do count down
    if self.countdown ~= "inf" then

        local dt = gs.updatePeriod / 1000.0

        --update according to time
        self.countdown = self.countdown - gs.updatePeriod

        --if the countdown time is done, kill ourself
        if self.countdown <= 0 then
            --kill ourself
            self.active = false
        end
    end

end


--==============================================================================
-- function:  MessageRender(self, screen)
-- author:    Myque Ouellette
-- created:   May 2, 2006
-- returns:   nothing
-- descript:  Take the message and renders it onto the screen
--==============================================================================
function MessageRender(self, screen)

    local msgFont = self.fontType

    --pull in each letter of string into a table
    local tmpTbl = StringTable(self.message)

    local pos = 0  --position placeholder

    --define x and y print position on screen
    local x = self.x + gFont[msgFont].charWidth
    local y = self.y + gFont[msgFont].charWidth

    --for each character in string
    for i = 1, table.getn(tmpTbl) do

        --find its position in the table, column, then row
        local column = (math.mod(string.byte(tmpTbl[i]), 16) * gFont[msgFont].charWidth) + gFont[msgFont].charWidth / 5
        local row = math.floor(string.byte(tmpTbl[i]) / 16) * gFont[msgFont].charWidth
        --send to the draw font funciton that draws only the appropriate letter
        DrawFont(screen, gFont[msgFont].font, pos + x, y, gFont[msgFont].charWidth / 1.5, gFont[msgFont].charWidth, column, row)
        --increment position for next letter
        pos = pos + (gFont[msgFont].charWidth / 1.5)

    end

end


--==============================================================================
-- function:  Msg (text, countdown, x, y)
-- author:    Myque Ouellette
-- created:   May 2, 2006
-- returns:   a (message table to add to the actors table)
-- descript:  Constructs a message actor for display on screen
--==============================================================================
function Msg(text, x, y, countdown, fontNum)

    --start with actor defaults
    local a = Actor({})

    --assign message and countdown values (if nil then displays indefinitely)
    a.type = "message"
    a.message = text
    a.fontType = fontNum or 1
    a.countdown = countdown or 5000
    a.x = x or 0
    a.y = y or 0

    a.update = MessageUpdate
    a.render = MessageRender

    gGamestate:AddActor(a)

    return a

end


--==============================================================================
-- function:  TempMsg (num, text, countdown, x, y)
-- author:    Myque Ouellette
-- created:   May 2, 2006
-- returns:   a (message table to add to the actors table)
-- descript:  Constructs a message actor for display on screen, defined by channel
--            (if new message of same channel entered, old one is deleted)
--==============================================================================
function TempMsg(num, text, x, y, countdown, fontNum)

    --check to see if a message of that number exists, if so, delete it (so it can be replaced).
    for i = 1, table.getn(gGamestate.actors) do
        if gGamestate.actors[i].type == "message" .. num then
            gGamestate.actors[i].active = false
        end
    end

    --if there is no text then it is erasing this message
    if text == nil then
        return
    end

    --start with actor defaults
    local a = Actor({})

    --assign message and countdown values (if nil then displays indefinitely)
    a.type = "message" .. num
    a.message = text
    a.fontType = fontNum or 1
    a.countdown = countdown or 5000
    a.x = x or 0
    a.y = y or 0

    --set up render and update functions
    a.update = MessageUpdate
    a.render = MessageRender

    --add message to actor table for rendering
    gGamestate:AddActor(a)

    return a

end


--==============================================================================
-- function:  LoadSound(sfxName)
-- author:    Myque Ouellette
-- created:   May 2, 2006
-- returns:   sfx (loaded sound)
-- descript:  Loads a sound file into memory
--==============================================================================
function LoadSound(sfxName)

    --loads the indicated sound file
    local sfx = Mix_LoadWAV(GAME_PATH .. sfxName)

    --checks to make sure that the file loaded OK, if not print an error
    if sfx == nil then
        print("Error loading sound file: " .. SDL_GetError() .. ".\n")
    end

    --returns the loaded sound file
    return sfx

end


--==============================================================================
--Function: GetInputType(keyPress)
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  string
--Descript: Called during user input to get correct input text
--==============================================================================
function GetInputType(keyPress, fullString)

    --get the key name
    local txt = SDL_GetKeyName(keyPress)

    --if key name is backspace then remove last letter from string
    if txt == "backspace" then
        fullString = string.sub(fullString, 1, string.len(fullString) - 1)
        return fullString
    end

    --if key is a space, then set it to a space
    if txt == "space" then
        txt = " "
    --if key name is longer than one, it isn't a letter or number, ignore it
    elseif string.len(txt) > 1 then
        txt = ""
    end

    --if shift then capitalize letter
--     if KMOD_SHIFT then
--         txt = string.upper(txt)
--     else
--         txt = string.lower(txt)
--     end

    --add new key to string name and return it
    fullString = fullString .. txt
    return fullString

end


--==============================================================================
-- function:  FireBullet (xVel, yVel, xPos, yPos)
-- author:    Eric Bakutis
-- created:   August 28, 2006
-- returns:   A new bullet fired from a chopper and moving at set velocity
-- descript:  Create a bullet that's fired from the chopper.
--==============================================================================
function FireBullet(xVel, yVel, xPos, yPos, pFacing)

    --start with actor defaults
    local a = Actor({})

    --tell the game this is a bullet
    a.type = "bullet"
    a.name = "bullet"

    --set the bullet's starting x and y position based on the player's position
    a.position.x = xPos
    a.position.y = yPos

    --set velocity based on player velocity -- currently not used
    a.Xvelocity = xVel
    a.Yvelocity = yVel

    --set facing based on player facing
    a.facing = pFacing

    --set bullet sprite
    a.sprite = Sprite("bullet")

    --set properties--using monster properties so that we can handle
    --collisions with zombies using the existing combat function
    a.hitPoints = 1
    a.strength = 50
    a.dexterity = 50
    a.toughness = 50

    --bullets don't have weapons, armor or gold
    a.weapon = "none"
    a.armor = "none"
    gold = 0
    
    --make the bullet collide with things
    a.collidable = 1
    a.radius = 0.5 * a.sprite.w

    --attach player handlers
    a.update = BulletUpdate --use BulletUpdate to handle movement
    a.render = MonsterRender

    --return the new bullet
    return a

end


--set global variables for bombs
BOMB_DURATION = 5000

--==============================================================================
-- function:  DropBomb (xPos, yPos)
-- author:    Eric Bakutis
-- created:   August 28, 2006
-- returns:   A new bomb dropped from a chopper impacting at it's last x and y
-- descript:  Create a bomb that's dropped from the chopper
--==============================================================================
function DropBomb(xPos, yPos)

    --start with actor defaults
    local a = Actor({})

    --tell the game this is a bomb
    a.type = "bomb"
    a.name = "bomb"

    a.duration = BOMB_DURATION

    --set the bomb's starting x and y position based on the player's position
    a.position.x = xPos
    a.position.y = yPos

    --set bomb sprite
    a.sprite = Sprite("bomb")

    --set properties--using monster properties so that we can handle
    --collisions with zombies using the existing combat function
    a.hitPoints = 1
    a.strength = 50
    a.dexterity = 50
    a.toughness = 50

    --bombs don't have weapons, armor or gold
    a.weapon = "none"
    a.armor = "none"
    gold = 0

    --make the bomb collide with things
    a.collidable = 1
    a.radius = a.sprite.w --make the bomb explosion radius same as size

    --attach player handlers
    a.update = BulletUpdate --use BulletUpdate to handle movement
    a.render = MonsterRender

    --return the new bomb
    return a

end


--global variable that stores if waiting for user input or not
gInputLoop = false
--Global user input variable that stores input into a string
gUserInput = ""
--Global variables that check if waiting for input from save or text
gSaveState = 0
gTextState = 0
--global variable to track if character info displaying or not
gCharacterInfo = false
--is key repeat active or not
gRepeat = false
--global variable that stores if we're in combat and takes us out of combat
--after two seconds.... this is used to prevent overlapping combat messages
--if multiple combats take place in a two second period, we only allow one
gCombatCooldown = 70 --only reset after 70 ticks, or just over 2 seconds.
gCombatTimer = gCombatCooldown --set timer to cooldown
         

--==============================================================================
--Function: UpdateTick()
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  nothing
--Descript: Called at regular intervals to update the game state
--==============================================================================
function UpdateTick()

    --remove dead actors and add in new actors
    for k,v in gGamestate.actors do
        --if the actor is active then add to newActors list
        if v.active then
            table.insert(gGamestate.newActors, v)
        end
    end

    --make actors the newActors list (has only active in it)
    gGamestate.actors = gGamestate.newActors
    --reset newActors table
    gGamestate.newActors = {}

    --if the actor table isn't sorted then do so
    if not gActorSorted then
        SortPriority()
    end

    --call the update handler for each actor
    for k,v in gGamestate.actors do
--         if string.find(v.type, "message") then
--             print(v.type, v.message, v.active)
--         end
        v:update(gGamestate)
    end

    --only update once per the number of ticks specified in MovementFreq
    if (gPlayerUpdateMovement >= gPlayerUpdateMovementFreq and gPlayer.Landed == false) then

        --convert a table element to a number for comparison
        local iPlayerVelocityX = tonumber(gPlayer.Xvelocity)
        local iPlayerVelocityY = tonumber(gPlayer.Yvelocity)

        --update the player helicopter's movement based on velocity each tick
        if (iPlayerVelocityX == 0 and iPlayerVelocityY == 0) then
            --do nothing
        else

            --do a velocity check to determine how often we update
            if (iPlayerVelocityX == gPlayerMaxVelocity or iPlayerVelocityY == gPlayerMaxVelocity) then
                gPlayerUpdateMovementFreq = 3
            else
                gPlayerUpdateMovementFreq = 6
            end

            --update X movement (forward or back)
            if iPlayerVelocityX > 0 then
                gPlayerMoveX = "right"
            elseif iPlayerVelocityX < 0 then
                gPlayerMoveX = "left"
            end

            --update Y movement (forward or back)
            if iPlayerVelocityY > 0 then
                gPlayerMoveY = "up"
            elseif iPlayerVelocityY < 0 then
                gPlayerMoveY = "down"
            end

        end

        --reset gPlayerUpdateMovement
        gPlayerUpdateMovement = 0;

        --cap velocity to make sure we can't go above or below max and min
        if iPlayerVelocityX > gPlayerMaxVelocity then
            gPlayer.Xvelocity = gPlayerMaxVelocity
        end

        if iPlayerVelocityY > gPlayerMaxVelocity then
            gPlayer.Yvelocity = gPlayerMaxVelocity
        end

        if iPlayerVelocityX < -gPlayerMaxVelocity then
            gPlayer.Xvelocity = -gPlayerMaxVelocity
        end
    
        if iPlayerVelocityY < -gPlayerMaxVelocity then
            gPlayer.Yvelocity = -gPlayerMaxVelocity
        end

    --increment gPlayerUpdateMovement by 1
    else
        gPlayerUpdateMovement = gPlayerUpdateMovement + 1

    end
    
    --if gCombatState is true, start a timer
    --if gCombatTimer is 70-1, we will decrement it
    --if gCombatTimer is 0 or less, we will set gCombatState to false
    --(to allow another combat round) and reset gCombatTimer to
    --gCombatCooldown so that it can handle the next combat round.
    if (gCombatState == true) then
        if gCombatTimer <= 0 then
            gCombatState = false
            gCombatTimer = gCombatCooldown
        else
            gCombatTimer = gCombatTimer - 1
        end
    end


end


--==============================================================================
--Function: RenderFrame(screen,background)
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  nothing
--Descript: Called to render a new frame
--==============================================================================
function RenderFrame(screen,background)

    --clear screen
    screen:FillRect(nil,background)

    --draw the actors
    for k,v in gGamestate.actors do
        v:render(screen)
    end

    --flip
    screen:UpdateRect()

end


--==============================================================================
--Function: GameloopIteration()
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  nothing
--Descript: Call to update gamestate, runs update ticks and renders
--          according to elapsed time
--==============================================================================
function GameloopIteration()

    --run any necessary updates
    local time = SDL_GetTicks()
    local deltaTicks = time - gGamestate.lastUpdateTicks
    local updateCount = 0
    while deltaTicks > gGamestate.updatePeriod do

        --run update
        UpdateTick()
        deltaTicks = deltaTicks - gGamestate.updatePeriod
        gGamestate.lastUpdateTicks = gGamestate.lastUpdateTicks + gGamestate.updatePeriod
        updateCount = updateCount + 1

        --don't let more than 3 ticks go by without an update
        if updateCount >= 3 then
            gGamestate.lastUpdateTicks = time
            break
        end

    end

    --if we did any updates then render a frame
    if updateCount > 0 then

        RenderFrame(gGamestate.screen,gGamestate.background)
        gGamestate.frames = gGamestate.frames + 1

        --consume any pending input events (keyboard)
        local evtBuf = SDL_Event()
        while SDL_PollEvent(evtBuf) do
            HandleEvent(evtBuf)
        end


        --play music if wasn't already playing
        if not Mix_PlayingMusic() then
            Mix_PlayMusic(gMusic, 0)
        end

    end

end


--==============================================================================
--Function: EngineInit(argv)
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  nothing
--Descript: Initializes game, video and audio, game window info
--==============================================================================
function EngineInit(argv)

    local videoFlags = SDL_HWSURFACE .. SDL_ANYFORMAT
    local width, height = 1024,768
    local videoBpp = 32

    --check for args and set video mode accordingly
    argv = argv or {}
    local i = 1
    while argv[i] do
        if argv[i] == "-width" then
            --check to make sure arg is valid
            if type(argv[i+1]) ~= 'number' then
                print("Error.  Invalid arg for parameter '-width': ", argv[i+1])
            end
            width = tonumber(argv[i+1])
            i = i + 1
        elseif argv[i] == "-height" then
            --check to make sure arg is valid
            if type(argv[i+1]) ~= 'number' then
                print("Error.  Invalid arg for parameter '-height': ", argv[i+1])
            end
            height = tonumber(argv[i+1])
            i = i + 1
        elseif argv[i] == "-fullscreen" then
            videoFlags = videoFlags .. SDL_FULLSCREEN
        else
            print("Usage: mainProgram [-width N][-height N][-fullscreen]\n")
            os.exit(1)
        end
        i = i + 1
    end

    --Set video mode
    gGamestate.screen = SDL_SetVideoMode(width, height, videoBpp, videoFlags)
    if gGamestate.screen == nil then
        print("Couldn't set ", width, "x", height, " video mode: ", SDL_GetError())
        os.exit(2)
    end

    gGamestate.background = SDL_MapRGB(gGamestate.screen.format, 0, 0, 0)
    SDL_ShowCursor( SDL_DISABLE )

    --Print out information about our surfaces
    print("Screen is at ", gGamestate.screen.format.BitsPerPixel, " bits per pixel.\n")
    if gGamestate.screen.flags(SDL_HWSURFACE) then
        print("Screen is in video memory")
    else
        print("Screen is in system memory")
    end
    if gGamestate.screen.flags(SDL_DOUBLEBUF) then
        print("Screen has double buffering enabled")
    end

    --Set window caption and icon
    SDL_WM_SetCaption(GAME_NAME, "ChopNorth.bmp")
    --SDL_WM_SetCaption(GAME_NAME, "player.bmp")

    --initialize audio
    if (Mix_OpenAudio(44100, AUDIO_S16SYS, 2, 2048) < 0) then
        print("Failed to initialize audio device. Reason: ", SDL_GetError())
        Mix_CloseAudio()
        os.exit(2)
    end

    --load in music
    --added music for choplifter
    gMusic = Mix_LoadMUS(GAME_PATH .. "d_e1m5.mid")
    --gMusic = Mix_LoadMUS(GAME_PATH .. "(sblu)moon6.xm")
    if gMusic == nil then
        print("Error loading music file: " .. SDL_GetError() .. ".\n" )
    end
    --set music volume
    Mix_VolumeMusic(-1, gMusVol)

    --and sound effects
    gSfxExplode = LoadSound("explode.wav")
    
    --load new sound effect for Choplifter
    gSfxBang = LoadSound("bang.wav")
    gSfxBomb = LoadSound("bomb.wav")
    gSfxRescue = LoadSound("rescue.wav")
    gSfxHumanDie = LoadSound("humandie.wav")
    gSfxZombieDie = LoadSound("zombiedie.wav")

    --set sound volume
    Mix_Volume(gVolume)

    --init timer
    gGamestate.beginTime = SDL_GetTicks()
    gGamestate.lastUpdateTicks = gGamestate.beginTime

end


--==============================================================================
--Function: EngineLoop()
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  nothing
--Descript: Loops until gamestate.active = false, then prints out info 
--          and closes stuff down
--==============================================================================
function EngineLoop()

    --loops while the gamestate is active (only changes with event)
    while gGamestate.active do
        GameloopIteration()
    end

    --Print out some timing info on exit
    local currentTime = SDL_GetTicks()
    --close audio channels
    Mix_CloseAudio()
    if currentTime > gGamestate.beginTime then
        print((gGamestate.frames*1000)/(currentTime - gGamestate.beginTime), " frames per second\n")
    end

    os.exit()
end


--Initialize Engine
EngineInit(arg)




