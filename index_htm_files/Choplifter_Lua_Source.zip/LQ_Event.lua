--==============================================================================
--File:     LuaQuest_Event
--Author:   Myque Ouellette
--Date:     December 11, 2006
--Descript: How to handle a key or mouse event in LuaQuest
--==============================================================================


--==============================================================================
--Function: HandleEvent(event)
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Return:   nothing
--Descript: Called by main game loop when it detects event
--==============================================================================
function HandleEvent(event)

    --if we are in a text input loop then wait for text
    if gInputLoop == true then

        --disable key repeat if active
        if gRepeat == true then
            SDL_EnableKeyRepeat(0,1000)
            gRepeat = false
        end

        --if key down
        if event.type == SDL_KEYDOWN then
            --find out what key
            local press = event.key.keysym.sym

            --if enter or escape, exit the loop
            if press == SDLK_KP_ENTER or press == SDLK_RETURN then
                --if the text input flag is set, pass the text to the text parser function
                if gTextState == 1 then
                    --enter the shop function to see if bought something
                    Shop(gShopList, gUserInput)
                end

                return
            end

            if press == SDLK_ESCAPE then

                if gTextState == 1 then
                    gTextState = 0
                    --break out of input loop and clear text
                    gInputLoop = false
                    for i = 1, 12 do
                        TempMsg(i)
                    end
                end

                return
            end


            --otherwise get keypress and add to input variable
            gUserInput = GetInputType(press, gUserInput)

        end

        --changed by TEB ================================================
        --print user input string
        TempMsg(82, gUserInput, 300, 420, "inf", 1)

    --check to see if key was pressed
    elseif event.type == SDL_KEYDOWN then
        local press = event.key.keysym.sym

        local mod = event.key.keysym.mod
--        print(mod)

        if (press ~= SDLK_UP) and (press ~= SDLK_DOWN) and (press ~= SDLK_RIGHT) and (press ~= SDLK_LEFT) then
            --disable key repeat if active
            if gRepeat == true then
                SDL_EnableKeyRepeat(0,1000)
                gRepeat = false
            end
        end


        --if key was Q then exit game
        if press == SDLK_q then
            --if you are in a menu then q will quit
            if gManager.state ~= "playing" then
                gGamestate.active = false
            end
        end

        --if press escape then pause, or unpause if already paused
        if press == SDLK_ESCAPE then
            --set gameloaded to false
            gGameLoaded = false

            --if its paused, unpause
            if gManager.state == "paused" then
                gManager.state = "playing"
            --added this so ESC will clear Help screen as well
            elseif gManager.state == "help" then
                gManager.state = "playing"
            elseif gManager.state == "playing" then
                --otherwise pause game if you are playing
                gManager.state = "paused"
            end
        end

        --if press n = new game (only in main menu)
        if press == SDLK_n then
            --if you are in the main menu then n will start a new game
            if gManager.state == "main" then
                gManager.state = "setup"
            end
        end

        --if press r = restart (only in pause menu)
        if press == SDLK_r then
            --if you are in pause menu then r will restart
            if gManager.state == "paused" then
                Restart()
            end
        end

        --if press h bring up help menu (toggle)
        if press == SDLK_h then
            --typing h brings up the help screen
            if gManager.state == "help" then
                gManager.state = "playing"
            else
                gManager.state = "help"
            end
        end

        --No need to ever display character stats, all character stats are
        --displayed on screen all the time and update there.

        --if press c then bring up character info in game, continue if in pause menu
--         if press == SDLK_c then
--             --if playing, then c brings up character information
--             if gManager.state == "playing" then
--                 --check to see if info is still up, if not then show it
--                 if gCharacterInfo == false then
--                     gCharacterInfo = true
--                     --show character information
--                     --      ID,    string ,        xpos,ypos, time (0-inf ms),  font(1-2)
--                     TempMsg(111, "CHARACTER INFO", 200, 100, "inf", 1)
--                     TempMsg(111, "Strength: " .. gPlayer.strength, 200, 125, "inf", 1)
--                     TempMsg(111, "Dexterity: " .. gPlayer.dexterity, 200, 150, "inf", 1)
--                     TempMsg(111, "Toughness: " .. gPlayer.toughness, 200, 175, "inf", 1)
-- 
--                     for i = 1, table.getn(gWeaponTable) do
--                         if gPlayer.weapon == gWeaponTable[i].name then
--                             TempMsg(111, "Weapon: " .. gPlayer.weapon .. "\t Damage: " .. gWeaponTable[i].damage, 200, 200, "inf", 1)
--                         end
--                     end
-- 
--                     for i = 1, table.getn(gArmorTable) do
--                         if gPlayer.armor == gArmorTable[i].name then
--                             TempMsg(111, "Armor: " .. gPlayer.armor .. "\t Defense: " .. gArmorTable[i].defense, 200, 225, "inf", 1)
--                         end
--                     end
--                 else
--                     --otherwise clear it all
--                     gCharacterInfo = false
--                     TempMsg(111)
--                 end
-- 
--             --if in the pause menu, c stands for continue
--             elseif gManager.state == "paused" then
-- 
--                 gManager.state = "playing"
--
--             end
--         end

        --the following only work while playing
        if gManager.state == "playing" then

            --only do up, down, left and right if the player is airborne
            if press == SDLK_UP and gPlayer.Landed == false then

                --added for chopper movement -- add X or Y velocity based on
                --direction
                if gPlayer.facing == "N" then
                    --chopper has accelerated North, add 1 to Y velocity.
                    gPlayer.Yvelocity = gPlayer.Yvelocity + 1
                elseif
                gPlayer.facing == "E" then
                    --chopper has accelerated East, add 1 to X velocity.
                    gPlayer.Xvelocity = gPlayer.Xvelocity + 1
                elseif
                gPlayer.facing == "S" then
                    --chopper has accelerated South, subtract 1 f Y velocity.
                    gPlayer.Yvelocity = gPlayer.Yvelocity - 1
                elseif
                gPlayer.facing == "W" then
                    --chopper has accelerated West, subtract 1 from X velocity.
                    gPlayer.Xvelocity = gPlayer.Xvelocity - 1
                end

                --added for chopper movement -- removed since movement is now
                --handled in UpdateTick
--                 if gPlayer.facing == "N" then
--                     gPlayerMove = "up"
--                 elseif
--                 gPlayer.facing == "E" then
--                     gPlayerMove = "right"
--                 elseif
--                 gPlayer.facing == "S" then
--                     gPlayerMove = "down"
--                 elseif
--                 gPlayer.facing == "W" then
--                     gPlayerMove = "left"
--                 end

                --gPlayerMove = "up"

                --enable key repeat
                if gRepeat == false then
                    SDL_EnableKeyRepeat(50,500)
                    gRepeat = true
                end
            end

            if press == SDLK_DOWN and gPlayer.Landed == false then

                --added for chopper movement -- add X or Y velocity based on
                --direction
                if gPlayer.facing == "N" then
                    --chopper has decelerated while facing North, subtract 1Y.
                    gPlayer.Yvelocity = gPlayer.Yvelocity - 1
                elseif
                gPlayer.facing == "E" then
                    --chopper has decelerated while facing East, subtract 1X.
                    gPlayer.Xvelocity = gPlayer.Xvelocity - 1
                elseif
                gPlayer.facing == "S" then
                    --chopper has decelerated while facing South, add 1Y.
                    gPlayer.Yvelocity = gPlayer.Yvelocity + 1
                elseif
                gPlayer.facing == "W" then
                    --chopper has decelerated while facing West, add 1X.
                    gPlayer.Xvelocity = gPlayer.Xvelocity + 1
                end

--                 --added for chopper movement -- removed since movement is now
--                 if gPlayer.facing == "N" then
--                     gPlayerMove = "down"
--                 elseif
--                 gPlayer.facing == "E" then
--                     gPlayerMove = "left"
--                 elseif
--                 gPlayer.facing == "S" then
--                     gPlayerMove = "up"
--                 elseif
--                 gPlayer.facing == "W" then
--                     gPlayerMove = "right"
--                 end

                --gPlayerMove = "down"

                --enable key repeat
                if gRepeat == false then
                    SDL_EnableKeyRepeat(50,500)
                    gRepeat = true
                end
            end

            if press == SDLK_LEFT and gPlayer.Landed == false then

               --added for chopper movement
                if gPlayer.facing == "N" then
                    gPlayer.facing = "W"

                    --added for movement
                    gPlayer.sprite = Sprite("ChopAirWest")

                elseif
                gPlayer.facing == "W" then
                    gPlayer.facing = "S"

                    --added for movement
                    gPlayer.sprite = Sprite("ChopAirSouth")

                elseif
                gPlayer.facing == "S" then
                    gPlayer.facing = "E"

                    --added for movement
                    gPlayer.sprite = Sprite("ChopAirEast")

                elseif
                gPlayer.facing == "E" then
                    gPlayer.facing = "N"

                    --added for movement
                    gPlayer.sprite = Sprite("ChopAirNorth")

                end

                --gPlayerMove = "left"

                --enable key repeat
                if gRepeat == false then
                    SDL_EnableKeyRepeat(50,500)
                    gRepeat = true
                end
            end

            if press == SDLK_RIGHT and gPlayer.Landed == false then

                --added for chopper movement
                if gPlayer.facing == "N" then
                    gPlayer.facing = "E"

                    --added for movement
                    gPlayer.sprite = Sprite("ChopAirEast")

                elseif
                gPlayer.facing == "E" then
                    gPlayer.facing = "S"

                    --added for movement
                    gPlayer.sprite = Sprite("ChopAirSouth")

                elseif
                gPlayer.facing == "S" then
                    gPlayer.facing = "W"

                    --added for movement
                    gPlayer.sprite = Sprite("ChopAirWest")

                elseif
                gPlayer.facing == "W" then
                    gPlayer.facing = "N"

                    --added for movement
                    gPlayer.sprite = Sprite("ChopAirNorth")

                end

                --gPlayerMove = "right"

                --enable key repeat
                if gRepeat == false then
                    SDL_EnableKeyRepeat(50,500)
                    gRepeat = true
                end
            end

            --handle launching and landing the chopper
            if press == SDLK_SPACE then

                --if the chopper is airborne and no collision was detected...
                if (gPlayer.Landed == false) then

                    --if gInTown is true,  we're at homebase and we can land, we
                    --don't need to do a collision check with the town
                    if (gInTown == true) then
                        --offload humans and award resource points if necessary
                        if (gPlayer.humans > 0) then
                            --tell player what happened
                            TempMsg(84, "You saved " .. gPlayer.humans .. " people!", 300, 440, 2000, 1)

                            --increment score
                            gPlayer.score = gPlayer.score + (150*gPlayer.humans)

                            --award resource points
                            --figure out how much the player gets
                            local iResourcePointsAward = 15 * gPlayer.humans
                            --tell the player how much RP they got
                            TempMsg(86, "You gained " .. iResourcePointsAward .. " Resource Points.", 300, 460, 2000, 1)
                            gPlayer.gold = gPlayer.gold + iResourcePointsAward

                            --offload humans
                            gPlayer.humans = 0

                            --land the chopper
                            gPlayer.Landed = true

                            --decrement fuel required to land
                            gPlayer.fuelPoints = gPlayer.fuelPoints - gPlayer.landingCost

                            --swap the chopper to a sprite without blades moving
                            if gPlayer.facing == "N" then
                                gPlayer.sprite = Sprite("ChopNorth")
                            elseif gPlayer.facing == "E" then
                                gPlayer.sprite = Sprite("ChopEast")
                            elseif gPlayer.facing == "S" then
                                gPlayer.sprite = Sprite("ChopSouth")
                            elseif gPlayer.facing == "W" then
                                gPlayer.sprite = Sprite("ChopWest")
                            end

                            --kill all velocity since we landed
                            gPlayer.Xvelocity = 0
                            gPlayer.Yvelocity = 0

                        --we didn't have any humans on board, so land normal
                        else

                            --land the chopper
                            gPlayer.Landed = true

                            --decrement fuel required to land
                            gPlayer.fuelPoints = gPlayer.fuelPoints - gPlayer.landingCost

                            --swap the chopper to a sprite without blades moving
                            if gPlayer.facing == "N" then
                                gPlayer.sprite = Sprite("ChopNorth")
                            elseif gPlayer.facing == "E" then
                                gPlayer.sprite = Sprite("ChopEast")
                            elseif gPlayer.facing == "S" then
                                gPlayer.sprite = Sprite("ChopSouth")
                            elseif gPlayer.facing == "W" then
                                gPlayer.sprite = Sprite("ChopWest")
                            end

                            --kill all velocity since we landed
                            gPlayer.Xvelocity = 0
                            gPlayer.Yvelocity = 0

                        end

                    --if gInTown is false, we need to make further checks
                    --before landing to see if we're on top of terrain
                    else

                        --land the chopper
                        gPlayer.Landed = true

                        --do a collision check--make sure the chopper can land and no
                        --terrain or monster is in the way
                        local bCantLand = false
                        bCantLand = CollisionCheck(gPlayer,gGamestate)
                        --Debugging message, removed
                        --TempMsg(50, "CollisionCheck: " .. tostring(bCantLand), 16, 400, "inf", 1)

                        --if the chopper collides with something, take off again
                        --no other adjustments needed
                        if (bCantLand == true) then
                            gPlayer.Landed = false

                        --if we collided with nothing, we can land as normal
                        else

                            --decrement fuel required to land
                            gPlayer.fuelPoints = gPlayer.fuelPoints - gPlayer.landingCost

                            --swap the chopper to a sprite without blades moving
                            if gPlayer.facing == "N" then
                                gPlayer.sprite = Sprite("ChopNorth")
                            elseif gPlayer.facing == "E" then
                                gPlayer.sprite = Sprite("ChopEast")
                            elseif gPlayer.facing == "S" then
                                gPlayer.sprite = Sprite("ChopSouth")
                            elseif gPlayer.facing == "W" then
                                gPlayer.sprite = Sprite("ChopWest")
                            end

                            --kill all velocity since we landed
                            gPlayer.Xvelocity = 0
                            gPlayer.Yvelocity = 0
                        end

                    end

                --otherwise,
                else
                    --take off!
                    gPlayer.Landed = false

                    --decrement fuel required to launch
                    gPlayer.fuelPoints = gPlayer.fuelPoints - gPlayer.launchingCost

                    --swap the chopper to a sprite with blades moving
                    if gPlayer.facing == "N" then
                        gPlayer.sprite = Sprite("ChopAirNorth")
                    elseif gPlayer.facing == "E" then
                        gPlayer.sprite = Sprite("ChopAirEast")
                    elseif gPlayer.facing == "S" then
                        gPlayer.sprite = Sprite("ChopAirSouth")
                    elseif gPlayer.facing == "W" then
                        gPlayer.sprite = Sprite("ChopAirWest")
                    end

                end

                --gPlayerMove = "right"

                --enable key repeat
                if gRepeat == false then
                    SDL_EnableKeyRepeat(50,500)
                    gRepeat = true
                end
            end

            --handle firing machineguns
            if (press == SDLK_RCTRL) and (gPlayer.bullets ~= 0) then

                --create a new bullet
                local newBullet = Actor

                --decrement ammo
                gPlayer.bullets = gPlayer.bullets - 1

                --play bullet fire sound
                Mix_PlayChannel(-1, gSfxBang, 0)

                if gPlayer.facing == "N" then
                     --FireBullet(xVel, yVel, xPos, yPos)
                     newBullet = FireBullet(gPlayer.Xvelocity, gPlayer.Yvelocity + 1, gPlayer.position.x, gPlayer.position.y, gPlayer.facing)
                     gGamestate:AddActor(newBullet)
                elseif gPlayer.facing == "E" then
                     --FireBullet(xVel, yVel, xPos, yPos)
                     newBullet = FireBullet(gPlayer.Xvelocity + 1, gPlayer.Yvelocity, gPlayer.position.x, gPlayer.position.y, gPlayer.facing)
                     gGamestate:AddActor(newBullet)
                elseif gPlayer.facing == "S" then
                     --FireBullet(xVel, yVel, xPos, yPos)
                     newBullet = FireBullet(gPlayer.Xvelocity, gPlayer.Yvelocity - 1, gPlayer.position.x, gPlayer.position.y, gPlayer.facing)
                     gGamestate:AddActor(newBullet)
                elseif gPlayer.facing == "W" then
                     --FireBullet(xVel, yVel, xPos, yPos)
                     newBullet = FireBullet(gPlayer.Xvelocity - 1, gPlayer.Yvelocity, gPlayer.position.x, gPlayer.position.y, gPlayer.facing)
                     gGamestate:AddActor(newBullet)
                end

                --enable key repeat
                if gRepeat == false then
                    SDL_EnableKeyRepeat(50,500)
                    gRepeat = true
                end

            end

            --handle dropping bombs
            if press == SDLK_RALT and (gPlayer.bombs ~= 0)then

                --create a new bomb
                local newBomb = Actor
                
                --decrement bombs
                gPlayer.bombs = gPlayer.bombs - 1
                
                --play bomb fire sound
                Mix_PlayChannel(-1, gSfxBomb, 0)

                newBomb = DropBomb(gPlayer.position.x, gPlayer.position.y)
                gGamestate:AddActor(newBomb)

                --enable key repeat
                if gRepeat == false then
                    SDL_EnableKeyRepeat(50,500)
                    gRepeat = true
                end

            end

            --if the player hits E (enter town) then show shop and wait for input
            if (press == SDLK_e and gPlayer.Landed == true) then
                --if the player is in a town
                if gInTown then
                
                    --tell monsters to stop moving
                    gPlayer.paused = true

                    --ask for input

                    --===================new code added by TEB for shop list
                    --get a new shop item list
                    gShopList = ShopItemList()

                    --display this shop item list for the user
                    ShopItemDisplay(gShopList)

                    --ask the user what they'd like to purchase
                    TempMsg(80, "Type the name of the item you want to purchase:", 300, 400, "inf", 1)

                    --set input loop to true
                    gInputLoop = true

                    --reset user input variables
                    gUserInput = ""
                    gTextState = 1

                end
            end

        end

        --take a screenshot
  		if press == SDLK_z then
            --check to see if screenshot exists
            while fExists(GAME_PATH .. SCREENSHOT .. gShotCount .. ".bmp") do
                gShotCount = gShotCount + 1
            end
            --write screenshot
			gGamestate.screen:SaveBMP( SCREENSHOT .. gShotCount .. ".bmp" )

			--tell player a screenshot was written, do this after the shot
			--is saved so that we don't get it IN the shot
            TempMsg(400, "Screenshot Saved", 50, 50, 2000, 1)
		end

        --save the game
  		if press == SDLK_s then
          	SaveGame()
        end

        --load the game
  		if press == SDLK_l then
            --give the function a game to load
            local sGametoLoad = "C:\\LuaScripts\\Choplifter\\savegame.txt"
            --load the game
            LoadGame(sGametoLoad)
            --start the game playing
            gManager.state = "playing"
        end

        --if right bracket increase music volume
        if press == SDLK_RIGHTBRACKET then
            gMusVol = gMusVol + 16
            --check to make sure volume is not at max already
            if gMusVol >= MAX_VOLUME then
                Mix_VolumeMusic(128)
            --if not, then increase the volume
            else
                Mix_VolumeMusic(gMusVol)
            end
        end

        --if left bracket decrease music volume
        if press == SDLK_LEFTBRACKET then
            gMusVol = gMusVol - 16
            --check to make sure volume is not at max already
            if gMusVol <= 0 then
                Mix_VolumeMusic(0)
            --if not, then increase the volume
            else
                Mix_VolumeMusic(gMusVol)
            end
        end

        --if equals sign increase overall volume
        if press == SDLK_EQUALS then
            gVolume = gVolume + 16
            --check to make sure volume is not at max already
            if gVolume >= MAX_VOLUME then
                Mix_VolumeMusic(-1, 128)
            --if not, then increase the volume
            else
                Mix_Volume(-1, gVolume)
            end
        end

        --if minus decrease overall volume
        if press == SDLK_MINUS then
            gVolume = gVolume - 16
            --check to make sure volume is not at max already
            if gVolume <= 0 then
                Mix_Volume(-1, 0)
            --if not, then increase the volume
            else
                Mix_Volume(-1, gVolume)
            end
        end

    --if they send SDL_QUIT constant then exit game
    elseif event.type == SDL_QUIT then
        gGamestate.active = false
    end

end
