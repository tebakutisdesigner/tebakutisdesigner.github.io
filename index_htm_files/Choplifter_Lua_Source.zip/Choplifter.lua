--==============================================================================
--File:     Choplifter
--Author:   Eric Bakutis
--Date:     September 17, 2007
--Descript: Choplifter: Zombie Apocalypse
--Note:     Modified and expanded from LuaQuest.lua
--          by Myque Ouellette
--Params:   [-width N] [-height N] [-fullscreen]
--==============================================================================


--==============================================================================
--Author:   Myque Ouellette
--Date:     May 1, 2006
--Descript: Example Game
--Note:     Initial setup and directory checking
--==============================================================================

--load the lib.sys library that has the check directory (chdir) function
USES 'lib.sys'

-- The game needs to be run in the same dir with its bitmaps:
GAME_PATH = lib.sys.chdir( "c:\\LuaScripts\\Choplifter\\" )
                                                                         
--if the directory doesn't exist then error out
if not GAME_PATH then
    error "No such path!"
--otherwise change directories
else
    print "\n\n"
    lib.sys.chdir( oldDir )
end

--set declare GAME_PATH constant and check to see if art is there
if not lib.static.listdir(GAME_PATH, "terrain1.*") then
    GAME_PATH = "C:\\LuaScripts\\sdl_demo\\"
    if not lib.static.listdir(GAME_PATH, "terrain1.*") then
        error "Missing art!"
    end
end

--Load other libraries, assign aliases                -
USES('lib.sdl2',"global")
USES('lib.vec2d')
USES('lib.sdl_mixer',"global")

SDL = ASSUME(lib.sdl2)

--Pre-assign some variables
vec2 = ASSUME(lib.vec2d.new)

fExists = lib.static.fileinfo

--set the default music volume
gMusVol = 64
--set the default volume
gVolume = 128

--global variable to check if it the actor table is sorted
gActorSorted = false

--set terrain density (number of terrain objects in world)
TERRAIN_DENSITY = 20
--set number of towns in the world... just one, the chopper's home base.
NUM_TOWNS = 1
--set minimum and maximum number of monsters
MAX_MONSTERS = 50 --set to 0 for testing, don't need- monsters right now

--maximum sound and music volume
MAX_VOLUME = 128

--size of the movement grid, which is also the size of player sprite
GRID_SIZE = 32

--define screen shot file name and shot number
SCREENSHOT = "temp"
gShotCount = 1

--Set the game name for display in window
GAME_NAME = "Choplifter: Zombie Apocalypse"

--load in the other modules
dofile(GAME_PATH .. "LQ_Core.lua")
dofile(GAME_PATH .. "LQ_Functions.lua")
dofile(GAME_PATH .. "LQ_UserFunctions.lua")
dofile(GAME_PATH .. "LQ_Event.lua")
dofile(GAME_PATH .. "LQ_Actor.lua")
dofile(GAME_PATH .. "LQ_Gameplay.lua")
dofile(GAME_PATH .. "LQ_Init.lua")


--==============================================================================
--Start the Game
--Author:   Myque Ouellette
--Date:     April 13, 2006
--==============================================================================
InitGame()
