--==============================================================================
--File:     LuaQuest_Functions
--Author:   Myque Ouellette
--Date:     December 11, 2006
--Descript: Utility functions for LuaQuest
--==============================================================================


--==============================================================================
--Function: ParticleSpray(position, velocity, count, spraySpeed, averageLife)
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  nothing
--Descript: Make spray of count particles at given location
--==============================================================================
function ParticleSpray(position, velocity, count, spraySpeed, averageLife)

    --create count number of particles
    for i = 1, count do

        --create particle actor
        local p = Particle({})

        --need to generate a dispersion vector of length <=1
        --generate random vectors until get a good one
        local dir
        repeat
            dir = vec2({ (math.random() * 2 - 1), (math.random() * 2 - 1) })
        until dir * dir <= 1

        --assign position and velocity
        p.position = position
        p.velocity = velocity + dir * spraySpeed

        p.countdown = (math.random() + math.random() + math.random()) / 3 * averageLife

        --add particle to actors list
        gGamestate:AddActor(p)
    end

end


--==============================================================================
--Function: CollisionCheck(self,gs)
--Author:   Myque Ouellette
--Date:     April 13, 2006
--Returns:  nothing
--Descript: checks for collision between two objects and passes it to the collision handler if there is
--==============================================================================
function CollisionCheck(self,gs)

    --check for collisions against all other actors
    for indx = 1,table.getn(gs.actors) do
        local a = gs.actors[indx]

        if self.type == "cursor" and a.type == "menuButton" then
            if a.visible == true then
                if self.position.x <= a.position.x + (a.sprite.w / 2)
                        and self.position.x >= a.position.x - (a.sprite.w / 2) then
                    if self.position.y <= a.position.y + (a.sprite.h / 2)
                            and self.position.y >= a.position.y - (a.sprite.h / 2) then
                        HandleCollision(self,a)
                    end
                end
            end
        end

        --check for collisions and respond
        if a and a ~= self and a.collidable then
            local disp = a.position - self.position
            local distanceSquared = disp * disp
            local sumRadiusSquared = (a.radius + self.radius) ^ 2

            if distanceSquared < sumRadiusSquared then
                --we have a collision

                --return the actors involved in the collision
                HandleCollision(self,a)

                --player can enter a town, nothing else can
                if self.type == "player" and a.type == "town" then
                    return false

                --make player not collide with terrain--TEB
                elseif (self.type == "player" and a.type == "terrain") then
                    if (self.Landed == false)  then
                        return false --no collision while flying
                    else
                        return true
                    end

                elseif (self.type == "terrain" and a.type == "player") then
                    if (a.Landed == false) then
                        return false --no collision while flying
                    else
                        return true
                    end

                --make player not collide with zombies while airborne--TEB
                elseif (self.type == "player" and a.name == "Zombie") then
                    if (self.Landed == false) then
                        return false --no collision while flying
                    else
                        return true
                    end

                elseif (self.name == "Zombie" and a.type == "player") then
                    if (a.Landed == false) then
                        return false --no collision while flying
                    else
                        return true
                    end

                --make player not collide with Humans while airborne--TEB
                elseif (self.type == "player" and a.name == "Human") then
                    if (self.Landed == false) then
                        return false --no collision while flying
                    else
                        return true
                    end

                elseif (self.name == "Human" and a.type == "player") then
                    if (a.Landed == false) then
                        return false --no collision while flying
                    else
                        return true
                    end

                --make player not collide with bomb explosions
                elseif (self.type == "player" and a.type == "bomb") or (self.type == "bomb" and a.type == "player") then
                    return false --no collision with bombs

                --make bullets not collide with bomb explosions
                elseif (self.type == "bullet" and a.type == "bomb") or (self.type == "bomb" and a.type == "bullet") then
                    return false --no collision with bombs

                --make bomb explosions not collide with other bomb explosions
                elseif (self.type == "bomb" and a.type == "bomb") then
                    return false --bomb explosions don't collide with each other
                    
                --make bomb explosions not collide with towns
                elseif (self.type == "town" and a.type == "bomb") or (self.type == "bomb" and a.type == "town") then
                    return false --no collision with bombs

                --make bullets destroy monsters on contact, plus themselves
                elseif (self.type == "bullet" and a.type == "monster") then

                    --update score for killing the monster
                    if (a.name == "Zombie") then
                        --killing zombies GOOD!
                        gPlayer.score = gPlayer.score + 30
                        --play sound for zombie death
                        Mix_PlayChannel(-1, gSfxZombieDie, 0)
                    elseif (a.name == "Human") then
                        --killing humans BAD!
                        gPlayer.score = gPlayer.score - 60
                        --play sound for human death
                        Mix_PlayChannel(-1, gSfxHumanDie, 0)
                    end

                    a.active = false --set the monster to inactive, it died
                    return true --so the bullet to destroy itself

                --make bombs destroy monsters on contact, but NOT destroy
                --themselves (they'll time out based on duration)
                --we need to do each collision possibility separate because
                --we only want to destroy one of the collidees, the monster
                elseif (self.type == "bomb" and a.type == "monster") then

                    --update score for killing the monster
                    if (a.name == "Zombie") then
                        --killing zombies GOOD!
                        gPlayer.score = gPlayer.score + 30
                        --play sound for zombie death
                        Mix_PlayChannel(-1, gSfxZombieDie, 0)
                    elseif (a.name == "Human") then
                        --killing humans BAD!
                        gPlayer.score = gPlayer.score - 60
                        --play sound for human death
                        Mix_PlayChannel(-1, gSfxHumanDie, 0)
                    end

                    if (self.type ~= "bomb") then
                        a.active = false --set the monster to inactive, it died
                    end

                    return false

                elseif (a.type == "bomb" and self.type == "monster") then

                    --update score for killing the monster
                    if (self.name == "Zombie") then
                        --killing zombies GOOD!
                        gPlayer.score = gPlayer.score + 30
                        --play sound for zombie death
                        Mix_PlayChannel(-1, gSfxZombieDie, 0)
                    elseif (self.name == "Human") then
                        --killing humans BAD!
                        gPlayer.score = gPlayer.score - 60
                        --play sound for human death
                        Mix_PlayChannel(-1, gSfxHumanDie, 0)
                    end

                    if (self.type ~= "bomb") then
                        self.active = false --set the monster to inactive, it died
                    end

                    return false

                --make bombs destroy terrain on contact, but NOT destroy
                --themselves (they'll time out based on duration)
                --we need to do each collision possibility separate because
                --we only want to destroy one of the collidees, the terrain
                elseif (self.type == "bomb" and a.type == "terrain") then

                    if (self.type ~= "bomb") then
                        a.active = false --set the terrain to inactive, died
                    end

                    return false

                elseif (a.type == "bomb" and self.type == "terrain") then

                    if (self.type ~= "bomb") then
                        self.active = false --set the terrain to inactive, it died
                    end

                    return false

                else
                    return true
                end

            end

        end

    end

    --if the collision check was on the player and we get to this point
    --then the player is no longer colliding with anything so you can turn
    --off the in town flag if it is on
    if self.type == "player" and gInTown == true then
        gInTown = false
    end

end


--==============================================================================
--Function: HandleCollision(a,b)
--Author:   Myque Ouellette
--Date:     May 02, 2006
--Returns:  nothing
--Descript: Handles collisions between a and b, uses type attribute to decide what to do
--==============================================================================
function HandleCollision(a,b)

    --disp is displacement vector; (b.position - a.position)
    if a.type == "cursor" then

        HandleCursorClick(a, b)

    end

    if (a.type == "player") then

        HandlePlayerCollision(a, b)

    end

    if a.type == "monster" then

        HandleMonsterCollision(a,b)

    end

end


--==============================================================================
--Function: HandleCursorClick(a,b)
--Author:   Myque Ouellette
--Date:     May 02, 2006
--Returns:  nothing
--Descript: Handles what happens if player clicks on object.
--==============================================================================
function HandleCursorClick(a,b)

    --draw particles at cursor position
    ParticleSpray(a.position, a.velocity, 6, 100, 300)

    --play explosion sound effect
    Mix_PlayChannel(-1, gSfxExplode, 0)

    if b.type == "menuButton" then

        if b.name == "new" then

            gManager.state = "setup"

        elseif b.name == "restart" then

            Restart()

        elseif b.name == "save" then

            --clear the menu buttons
            gMenu.new.visible = false
            gMenu.continue.visible = false
            gMenu.restart.visible = false
            gMenu.save.visible = false
            gMenu.load.visible = false
            gMenu.help.visible = false
            gMenu.quit.visible = false

            if fExists(GAME_PATH .. "LuaQuestSave.lua") then
                gInputLoop = true
                --ask for input
                TempMsg(1, "Save file already exists.  Are you sure you want to overwrite it? (Y/N)", 16,300,"inf",1)
                --reset user input variable
                gUserInput = ""
                gSaveState = 1
            else
            	SaveGame()
            end

        elseif b.name == "load" then

            LoadGame("LuaQuestSave")

        elseif b.name == "continue" then

            gManager.state = "playing"

        elseif b.name == "quit" then

            gGamestate.active = false

        elseif b.name == "help" then

            gManager.state = "help"

        end

    end

-- ****************************************************************************************************
--  --debug
    if b.type == "terrain" then

        --removed... don't want to destroy terrain with cursor
        --blow up terrain
        --b.active = false

        --removed this... don't want to generate new terrain when old terrain
        --is destroyed... did this both to adjust for the game and also so that
        --the loadgame function (which destroys all existing terrain) won't
        --end up creating new terrain before the saved terrain is loaded

        --add another actor (temporary)
        --no need to generate, we aren't blowing up.
        --gGamestate:AddActor(
            --Terrain({
                --position = { math.random(gGamestate.screen.w), math.random(gGamestate.screen.h) },
            --})
        --)

    end


-- ****************************************************************************************************

end


--global variable that flags if player is in town or not
gInTown = false

--==============================================================================
--Function: HandlePlayerCollision(a,b)
--Author:   Myque Ouellette
--Date:     May 02, 2006
--Returns:  nothing
--Descript: Handles collisions between player and b, uses type attribute to decide what to do
--==============================================================================
function HandlePlayerCollision(a,b)

    --we aren't doing anything if the player is airborne
    if (gPlayer.Landed == false) then
        --if the player encounters town then continue moving but set flag
        if b.type == "town" then
            gInTown = true
    --         tmp = "collide town true"
    --         Msg(tmp, 16, 400, 2000)
        end

        --if the palyer encounters a human or zombie while airborne, keep
        --moving

    else

        --if the player encounters a monster, stop moving and initiate combat
        --changed from type to name, since humans and zombies are 'monsters'
        --if a zombie touches the chopper, the zombie hits it
        if b.name == "Zombie" then
            gMouse = {}
            if gInTown == false then
                Combat(a,b)
            end
        end

--         --if a human touches the chopper, the humans get son board
--         if b.name == "Human" then
--             gMouse = {}
-- 
--             --we've got room, let him board.
--             if a.humans < 10 then
-- 
--                 --only board if not in town
--                 if gInTown == false then
--                     b.active = false
--                     a.humans = a.humans + 1
--                 end
-- 
--             --no room, can't get on, so freeze
--             else
--             
--                 --wait hopelessly
-- 
--             end
-- 
--         end

        --if the player encounters terrain, stop moving
        if b.type == "terrain" then
            --gMouse = {}
        end

        --if the player encounters town then continue moving but set flag
        if b.type == "town" then
            gInTown = true
    --         tmp = "collide town true"
    --         Msg(tmp, 16, 400, 2000)
        end
    end

end


--==============================================================================
--Function: HandleMonsterCollision(a,b)
--Author:   Myque Ouellette
--Date:     May 02, 2006
--Returns:  nothing
--Descript: Handles collisions between monster and b, uses type attribute to decide what to do
--==============================================================================
function HandleMonsterCollision(a,b)

    --if the player encounters a monster, stop moving and initiate combat
    --changed from type to name, since humans and zombies are 'monsters'
    --if a zombie touches the chopper, the zombie hits it
    if (a.name == "Zombie" and b.type == "player" and b.Landed == true) then
        gMouse = {}
        if gInTown == false then
            Combat(a,b)
        end

    elseif a.name == "Zombie" and b.name == "Human" then
        gMouse = {}
        ZombifyHuman(a,b)

    elseif a.name == "Human" and b.name == "Zombie" then
        gMouse = {}
        ZombifyHuman(b,a)

    end
    
    --if a zombie touches the homebase, damage the homebase
    if (a.name == "Zombie" and b.type == "town") then
        gMouse = {}
            Combat(a,b)
    end

    --if a human touches the chopper, the humans gets on board
    if (a.name == "Human" and b.type == "player" and b.Landed == true) then
        gMouse = {}

        --we've got room, let him board.
        if b.humans < 10 and b.type == "player" then

            --only board if not in town
            if gInTown == false then
                a.active = false
                b.humans = b.humans + 1
                --play sound for rescued human
                Mix_PlayChannel(-1, gSfxRescue, 0)
            end

        --no room, can't get on, so freeze
        else

            --wait hopelessly

        end

    end

end

--==============================================================================
--Function: ZombifyHuman(a,b)
--Author:   Eric Bakutis
--Date:     September 02, 2007
--Returns:  nothing
--Descript: Handles collisions between zombie a and human b, turning human b
--          into a zombie!
--==============================================================================
function ZombifyHuman(a,b)

    --Tell the player what just occurred.
    TempMsg(50, "Zombie bites down on human, turning him into a zombie!\n", 200,200, 2000, 1)
    
    --play zombified sound
    Mix_PlayChannel(-1, gSfxHumanDie, 0)

    --zombify the human who got bit
    --set up local variables to hold the human
    local xpos
    local ypos

    --save the human's position in variables
    xPos = b.position.x
    yPos = b.position.y

    --set the human to inactive (don't need him)
    b.active = false

    --grab our zombie from gEnemyTable
    local tRandomMonster = gEnemyTable[1]

    --spawn the zombie in the human's place
    local tMonsterPos = {}
    tMonsterPos.x = xPos
    tMonsterPos.y = yPos

    --add the monster's position data to the monster
    tRandomMonster.position = tMonsterPos

    --create a new table to hold our tRandomMonster so we don't overwrite
    --Because LUA changes all tables created from a single table as they
    --are changed, we need to use the tempTable function shown in class
    --to create a temporary table that is then inserted into the final
    --table we create from input. We do this because if we just
    --just inserted the table without doing the not-same table
    --function on it first, all entries in the final table would be
    --set to whatever the last change made to table was.
    local tTempRandomMonster = {}
        for k,v in tRandomMonster do
            if type(v) == "table" then
                for k1, v1 in v do
                    if tTempRandomMonster[k] == nil then
                        tTempRandomMonster[k] = {}
                    end
                        tTempRandomMonster[k][k1] = v1
                    end
                else
                    tTempRandomMonster[k] = v
                end
            end

    --add the new zombie to the actor table
    gGamestate:AddActor(
        Monster(tTempRandomMonster)
    )
end


--==============================================================================
-- function:  GetGrid()
-- author:    Myque Ouellette
-- created:   May 24, 2006
-- returns:   table with x and y positions
-- descript:  Finds random position on the grid for object
--==============================================================================
function GetGrid()

    --finds a random position on the screen
    local initX = math.random(gGamestate.screen.w)
    --divide by grid size and round down
    local floorX = math.floor(initX / GRID_SIZE)
    --multiply by grid size and then add half of grid size for proper final position
    local finalX = (floorX * GRID_SIZE) + GRID_SIZE/2

    --finds a random position on the screen
    local initY = math.random(gGamestate.screen.h)
    --divide by grid size and round down
    local floorY = math.floor(initY / GRID_SIZE)
    --multiply by grid size and then add half of grid size for proper final position
    local finalY = (floorY * GRID_SIZE) + GRID_SIZE/2

    --return the two numbers in a table
    return { finalX, finalY }

end


--==============================================================================
-- function:  Restart()
-- author:    Myque Ouellette
-- created:   May 24, 2006
-- returns:   nothing
-- descript:  Restarts the game
--==============================================================================
function Restart()

    --clear the game tables and key global variables
    gGamestate.actors = {}
    gGamestate.newActors = {}
    gPlayer = {}
    gManager = nil

    --re-initialize the game
    InitGame()

end
